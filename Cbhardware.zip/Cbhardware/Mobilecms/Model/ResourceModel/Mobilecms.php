<?php
 
namespace Cbhardware\Mobilecms\Model\ResourceModel;
 
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
 
class Mobilecms extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('cbhardware_mobilecmspage', 'id');
    }
}