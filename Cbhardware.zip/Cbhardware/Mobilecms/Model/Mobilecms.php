<?php			

namespace Cbhardware\Mobilecms\Model;
			
use Magento\Framework\Model\AbstractModel;
			
class Mobilecms extends AbstractModel
{
			
    protected function _construct()
    {
			
        $this->_init('Cbhardware\Mobilecms\Model\ResourceModel\Mobilecms');
    }
			
}

	