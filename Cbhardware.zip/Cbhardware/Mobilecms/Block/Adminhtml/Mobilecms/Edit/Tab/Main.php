<?php

namespace Cbhardware\Mobilecms\Block\Adminhtml\Mobilecms\Edit\Tab;
/**
 * Blog post edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_resourceConnection;

    protected $_drivermanagement;
    protected $_viewHelper;

    /**
     * @var \SR\Weblog\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Cbhardware\Mobilecms\Helper\Data $viewHelper,
        //ResourceConnectionFactory $_resourceConnection,DrivermanagementFactory $_drivermanagement,
        //\SR\Weblog\Model\Status $status,
        array $data = []
    ) {
        $this->_viewHelper = $viewHelper;
        $this->_systemStore = $systemStore;
        //$this->_status = $status;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /* @var $model \SR\Weblog\Model\BlogPosts */
        $model = $this->_coreRegistry->registry('cbhardware_mobilecms');

        $isElementDisabled = false;

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Page Information')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }
        $fieldset->addField(
            'page_title',
            'text',
            [
                'name' => 'page_title',
                'label' => __('Page Title'),
                'title' => __('Page Title'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
       /* $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Account Email'),
                'title' => __('Account Email'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );*/
        $fieldset->addField(
            'type',
            'select',
            array(
                'name' => 'type',
                'label' => __('Select Your Category'),
                'title' => __('Select Your Category'),
                'required' => true,
                'options' => $this->_viewHelper->getPageCategory()
           )
        );
        $fieldset->addField(
            'pdf_filename',
            'image',
            array(
                'name' => 'pdf_filename',
                'label' => __('Pdf Upload'),
                'title' => __('Pdf Upload'),
                'note' => 'Allow file type: Pdf',
           )
        );
        $fieldset->addField(
            'videotype',
            'select',
            array(
                'name' => 'videotype',
                'label' => __('Video Type'),
                'title' => __('Video Type'),
                'required' => false,
                'options' => ['0' => __('Select Type of video'),'normal' => __('Normal'), 'youtube' => __('Youtube')]
           )
        );
        $fieldset->addField(
            'video_link',
            'text',
            [
                'name' => 'video_link',
                'label' => __('Video Link'),
                'title' => __('Video Link'),
                'required' => false,
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'content',
            'Cbhardware\Mobilecms\Block\Adminhtml\Mobilecms\Editor\Editor',
            [
                'name' => 'content',
                'label' => __('Contents'),
                'required' => false,
            ]
        );
        $fieldset->addField(
            'active',
            'select',
            array(
                'name' => 'active',
                'label' => __('Active'),
                'title' => __('Active'),
                'required' => false,
                'options' => ['yes' => __('yes'), 'no' => __('no')]
           )
        );

        /*$fieldset->addField(
            'is_active',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Status'),
                'name' => 'is_active',
                'required' => true,
                'options' => $this->_status->getOptionArray(),
                'disabled' => $isElementDisabled
            ]
        );*/
        /*if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }*/

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Gendral Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Gendral Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
