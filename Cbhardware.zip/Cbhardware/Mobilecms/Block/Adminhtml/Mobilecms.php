<?php
namespace Cbhardware\Mobilecms\Block\Adminhtml;

class Mobilecms extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml';
        $this->_blockGroup = 'Cbhardware_Mobilecms';
        $this->_headerText = __('Manage Mobilecms Page');
        $this->_addButtonLabel = __('Add New Page');
        parent::_construct();
    }
}