<?php
namespace Cbhardware\Mobilecms\Helper;
/**
* 
*/
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $_resourceConnection;

    protected $_drivermanagement;
    
    public function __construct(\Magento\Framework\App\Helper\Context $context,
      \Magento\Framework\App\ResourceConnectionFactory $_resourceConnection,
      \Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement
  ){
    	parent::__construct($context);
    	$this->_resourceConnection = $_resourceConnection;

        $this->_drivermanagement = $_drivermanagement;

    }
    public function getPageCategory(){
        $result = array();
        $result['0']='Select your category';
        $result['video'] ='Video';
        $result['pdf'] ='Pdf';
        return $result;
    }
    
}
?>
