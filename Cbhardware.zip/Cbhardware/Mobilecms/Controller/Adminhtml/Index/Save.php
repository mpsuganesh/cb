<?php
namespace Cbhardware\Mobilecms\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;

class Save extends \Magento\Backend\App\Action
{
    protected $_mediaDirectory;
    protected $_fileUploaderFactory;

    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context,
       \Magento\Framework\Filesystem $filesystem,
       \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory)
    {
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    { 
        $image = $this->getRequest()->getFiles();
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $store = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface');
        
        $currentStore = $store->getStore();
        
        $mediaurl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);


        if ($data) {
            $model = $this->_objectManager->create('Cbhardware\Mobilecms\Model\Mobilecms');

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
            
            try {
              $path = $this->_mediaDirectory->getAbsolutePath('mobiledata/');;
              if(isset($data['pdf_filename']['delete'])){
                unlink($this->_mediaDirectory->getAbsolutePath('/').$data['pdf_filename']['value']);
                $data['pdf_filename'] = '';
            }else if($image['pdf_filename']['name'] != ''){
            // Save Image
                $uploader = $this->_fileUploaderFactory->create(['fileId' => $image['pdf_filename']]);
                $uploader->setAllowedExtensions(['pdf']);
                $uploader->setAllowRenameFiles(true);
                $result = $uploader->save($path);

                $fileName = $uploader->getUploadedFileName();
                if ($fileName) {
                    $data['pdf_filename'] = 'mobiledata/'.$fileName;
                }
            // Save Image
            }else{
                $data['pdf_filename'] = NULL;
            }
            $model->setData($data);
            $model->save();
            $this->messageManager->addSuccess(__('The Page has been saved.'));
            $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
            if ($this->getRequest()->getParam('back')) {
                return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
            }
            return $resultRedirect->setPath('*/*/');
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\Exception $e) {
           $this->messageManager->addError($e->getMessage());
       }

       $this->_getSession()->setFormData($data);
       return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
   }
   return $resultRedirect->setPath('*/*/');
}
}
