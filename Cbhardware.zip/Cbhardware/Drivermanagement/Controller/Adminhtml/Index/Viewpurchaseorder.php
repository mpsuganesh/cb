<?php
namespace Cbhardware\Drivermanagement\Controller\Adminhtml\Index;

class Viewpurchaseorder extends \Magento\Backend\App\Action
{
/**
* @var \Magento\Framework\View\Result\PageFactory
*/
protected $_coreRegistry = null;
protected $resultPageFactory;

/**
 * Constructor
 *
 * @param \Magento\Backend\App\Action\Context $context
 * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
 */
public function __construct(
	\Magento\Backend\App\Action\Context $context,
	\Magento\Framework\View\Result\PageFactory $resultPageFactory,
	\Magento\Framework\Registry $registry
) {
	parent::__construct($context);
	$this->_coreRegistry = $registry;
	$this->resultPageFactory = $resultPageFactory;
}

/**
 * Load the page defined in view/adminhtml/layout/exampleadminnewpage_helloworld_index.xml
 *
 * @return \Magento\Framework\View\Result\Page
 */
public function execute()
{
    $id = $this->getRequest()->getParam('id');
        $model = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Purchaseorders');
        if ($id) {
        $model->load($id);
        if (!$model->getId()) {
            $this->messageManager->addError(__('This Drivermanagement no longer exists.'));
            /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();

            return $resultRedirect->setPath('*/*/');
        }else{
             $this->_coreRegistry->register('cbhardware_purchaseorders', $model);
            //print_r($model->getData());
             //exit();
             $resultPage = $this->resultPageFactory->create();
        }
        }
        
       // echo $id;
        return  $resultPage;
}
}
?>
