<?php
namespace Cbhardware\Drivermanagement\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;

class Save extends \Magento\Backend\App\Action
{

    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context)
    {
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $store = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface');
        
        $currentStore = $store->getStore();
        
        $mediaurl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

        if ($data) {
            $model = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Drivermanagement');

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }

            try {
                //print_r($data);
                //exit();
                //$model->setData($data);
                
                $model->setDriverName($data['drivername']);
                $model->setEmail($data['email']);
                $model->setMobileNumber($data['mobile_number']);
                $model->setDob($data['dob']);
                $model->setLicenceNumber($data['licence_number']);
                $model->setLocations($data['locations']);
                $model->setExpireDate($data['date']);
                $model->setStatus($data['status']);
                $model->save();
                $this->messageManager->addSuccess(__('The driver has been saved.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving this driver.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
