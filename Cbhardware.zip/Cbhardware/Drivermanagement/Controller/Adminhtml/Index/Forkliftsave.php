<?php
namespace Cbhardware\Drivermanagement\Controller\Adminhtml\Index;
use Magento\Backend\App\Action;

class Forkliftsave extends \Magento\Backend\App\Action
{
    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context)
    {
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->_backendUrl = $objectManager->get('\Magento\Backend\Model\UrlInterface'); 
        $url = $this->_backendUrl->getUrl("drivermanagement/index/forkliftdetails");

        $data = $this->getRequest()->getPostValue();
        $forktitle = array_filter($data['forktitle']);
        $forkData = array();
        foreach ($forktitle as $titleId => $value) {
            $forkData[$value]=$data['forklift'][$titleId];
        }

        $forkliftVlaue = array_filter($forkData);
        if(!empty($forkliftVlaue)){
            $forkliftformData = json_encode($forkliftVlaue);
        }else{
            $forkliftformData = "";
        }
        if(!empty($data['model_type'])){
            $forkliftform = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Forkliftform')->getCollection()->addFieldToFilter('model_type',array('eq'=>$data['model_type']));
            $existsdata = $forkliftform->getData();
            if(!empty($existsdata)){
                foreach ($forkliftform as $forkliftdata) {
                    $forkliftdata->setModelType($data["model_type"]);
                    $forkliftdata->setForkliftForm($forkliftformData);
                }
                $forkliftform->save();
                $msg['status']="success";
                $msg['message']="successfully saved";

            }else{
                $forkliftform = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Forkliftform');
                $forkliftform->setModelType($data["model_type"]);
                $forkliftform->setForkliftForm($forkliftformData);
                $forkliftform->save();
                $msg['status']="success";
                $msg['message']="successfully saved";
                $msg['redirect_url'] = $url;
            }
            //print_r($forkliftform->getData());
        }else{
            $msg['status']="error";
            $msg['message']="model is empty";
        }
        echo json_encode($msg);
       
    }
}

