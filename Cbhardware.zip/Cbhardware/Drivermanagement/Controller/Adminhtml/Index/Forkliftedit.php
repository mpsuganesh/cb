<?php

namespace Cbhardware\Drivermanagement\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;

class Forkliftedit extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
        parent::__construct($context);
    }

    public function execute()
    {
        // 1. Get ID and create model
        $id = $this->getRequest()->getParam('id');
        $model = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Forkliftform');
        if ($id) {
        $model->load($id);
        if (!$model->getId()) {
            $this->messageManager->addError(__('This Drivermanagement no longer exists.'));
            /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();

            return $resultRedirect->setPath('*/*/');
        }else{
             $this->_coreRegistry->register('cbhardware_drivermanagement', $model);
            // print_r($model->getData());
             //exit();
             $resultPage = $this->resultPageFactory->create();
        }
        }
        
       // echo $id;
        return  $resultPage;
    }
}
