<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Salesorderconfirmations extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $salesorderconfirmations;
	protected $_pushnotiofications;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Salesorderconfirmations\Collection $salesorderconfirmations,
		\Cbhardware\Pushnotifications\Model\PushnotificationsFactory $_pushnotiofications,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->salesorderconfirmations = $salesorderconfirmations;
		$this->_pushnotiofications = $_pushnotiofications;
		$this->request = $request;
		return parent::__construct($context);

	}

	public function execute()
	{
		$orderid = $this->request->getParam('orderid');
		$orderType = $this->request->getParam('ordertype');
		$deliveryInstructions = $this->request->getParam('delivery_instructions');
		$referenceNo = $this->request->getParam('reference_no');
		if(!empty($orderid)&&(!empty($orderType))){
			$result = $this->resultJsonFactory->create();
			$cofirmationorder = $this->salesorderconfirmations->addFieldToFilter('orderid', $orderid);
			$existsdata = $cofirmationorder->getData();
			if(count($existsdata)>0){
				// sales order update 
				//foreach($cofirmationorder as $o)
				// end sales order update
				$status['status'] ="success";
				$status['message'] ="This data already confirmed..";
				$status['code'] ="200";
				$result->setData(['status'=>'success','confirmedstatus'=>$status]);
			}else{
				$cofirmationorder = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations');
				$cofirmationorder->setOrderid($orderid);
				$cofirmationorder->setOrderType($orderType);
				$cofirmationorder->setStage('confirmed');
				$cofirmationorder->setReferenceNo($referenceNo);
				$cofirmationorder->save();
				$orderData = array();
				$orderData[] = array('id'=>$orderid,'status'=>'APPROVED','stage'=>'Release To Pick','deliveryInstructions'=>$deliveryInstructions);
				$finalOrderData =  json_encode($orderData,true);
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders?loadboms=%7Bloadboms%7D",
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => "",
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 30,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => "PUT",
					CURLOPT_POSTFIELDS => $finalOrderData,
					CURLOPT_HTTPHEADER => array(
						"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi",
						"content-type: application/json"),
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);
				if ($err) {
					$result->setData(['status'=>'error','message'=>$err]);
				} else {
					$finalresponse = json_decode($response,true);
					if($finalresponse[0]['success']==1){
// send pushnotifications
						$salespersons = $this->_mobileapi->create()->getCollection()->addFieldToFilter('driver_details',0)->addFieldToFilter('device_token',array('notnull'=>true));
						if(count($salespersons->getData())>0){
							$pushnotiofications = $this->_pushnotiofications->create()->getCollection();
							$pushData = $pushnotiofications->getData();
							if($pushData[0]['status']=="test"&&$pushData[0]['active']=="yes"){
								$secretKey = $pushData[0]['secret_key'];
								$filePath  = $pushData[0]['file_name'];
								$gatewayUrl = $pushData[0]['gateway_url_test'];
								foreach($salespersons as $adminDetaiils){
									$deviceToken = $adminDetaiils->getDeviceToken();
									$ctx = stream_context_create();
									stream_context_set_option($ctx, 'ssl', 'local_cert', 'pub/media/'.$filePath);
									stream_context_set_option($ctx, 'ssl', 'passphrase', $secretKey);
									$fp = stream_socket_client($gatewayUrl, $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
									if (!$fp)
										$result->setData(['status'=>'success','message'=>'Failed to connect']);
										//exit("Failed to connect: $err $errstr" . PHP_EOL);
									$body['aps'] = array(
										'alert' => array(
											'title' => 'Release to pick',
											'body' => $referenceNo.' The order is assigned for picking',
										),
										'sound' => 'default'
									);
									$payload = json_encode($body);
									$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
									$result1 = fwrite($fp, $msg, strlen($msg));
									fclose($fp);
								}
							}else{
								if($pushData[0]['status']=="live"&&$pushData[0]['active']=="yes"){
									$secretKey = $pushData[0]['secret_key'];
									$filePath  = $pushData[0]['file_name'];
									$gatewayUrl = $pushData[0]['gateway_url_live'];
									foreach($salespersons as $adminDetaiils){
										$deviceToken = $adminDetaiils->getDeviceToken();
										$ctx = stream_context_create();
										stream_context_set_option($ctx, 'ssl', 'local_cert', 'pub/media/'.$filePath);
										stream_context_set_option($ctx, 'ssl', 'passphrase', $secretKey);
										$fp = stream_socket_client($gatewayUrl, $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
										if (!$fp)
											$result->setData(['status'=>'success','message'=>'Failed to connect']);
											//exit("Failed to connect: $err $errstr" . PHP_EOL);
										$body['aps'] = array(
											'alert' => array(
												'title' => 'Release to pick',
												'body' => $referenceNo.' The order is assigned for picking',
											),
											'sound' => 'default'
										);
										$payload = json_encode($body);
										$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
										$result1 = fwrite($fp, $msg, strlen($msg));
										fclose($fp);

									}

								}
							}

						}
// end send pushnotification
						$result->setData(['status'=>'success','message'=>'Order Confirmed']);

					}

				}
/*$status['status'] ="success";
$status['message'] ="successfuly confirmed..";
$status['code'] ="200";
$result->setData(['confirmedstatus' => $status]);*/
}
}
return $result;

//die('test');		
}
}