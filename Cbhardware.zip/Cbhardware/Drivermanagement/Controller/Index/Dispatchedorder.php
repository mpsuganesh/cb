<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Dispatchedorder extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_mediaDirectory;
	protected $_fileUploaderFactory;
	protected $_deliverydockets;
	protected $salesorderconfirmations;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Cbhardware\Drivermanagement\Model\DeliverydocketsFactory $_deliverydockets,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Salesorderconfirmations\Collection $salesorderconfirmations,
		\Magento\Framework\Filesystem $filesystem,
		\Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_deliverydockets = $_deliverydockets;
		$this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
		$this->_fileUploaderFactory = $fileUploaderFactory;
		$this->request = $request;
		$this->salesorderconfirmations = $salesorderconfirmations;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$result = $this->resultJsonFactory->create();
		$orderid = $this->request->getParam('orderid');
		$deliverdockets = $this->_deliverydockets->create()->getCollection()->addFieldToFilter('order_id', $orderid);
		$existsData = $deliverdockets->getData();
		if(count($existsData)>0){
			//$result->setData(['status'=>'error','message'=>'this order already Dispatched']);
			$dispatchedtime  = gmdate('c');
			$referenceno = $this->getRequest()->getParam('reference_no');
			$customerFirstname = $this->getRequest()->getParam('customer_firstname');
			$customerLastname = $this->getRequest()->getParam('customer_lastname');
			$stage = $this->getRequest()->getParam('stage');
			$address = $this->getRequest()->getParam('address');
			$docketimg = $this->getRequest()->getParam('docket_img');
			$driverid = $this->getRequest()->getParam('driver_id');
			//$dispatched = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Deliverydockets');
			$path = $this->_mediaDirectory->getAbsolutePath('mobiledata/');

			$signature = $this->getRequest()->getParam('signature');
			$totalAmount = $this->getRequest()->getParam('total_amount');
			$contactNumber = $this->getRequest()->getParam('contact_number');
			$email = $this->getRequest()->getParam('email');
			$comments = $this->getRequest()->getParam('comments');
			$company = $this->getRequest()->getParam('company');
			$driverName = $this->getRequest()->getParam('driver_name');
			$docketimages = json_decode($docketimg,true);
			if(!empty($docketimages)){
			foreach ($docketimages as $docketimg1) {
			$imageBase = base64_decode($docketimg1);
			$filname = uniqid() . '.png';
			$file = $path.$filname;
			$fname[] = $filname;
			file_put_contents($file, $imageBase);
			}
			$finalFilename = implode("@", $fname);
			}else{
				$finalFilename='';
			}
			if(!empty($signature)){
			$signatureimg = base64_decode($signature);
			$signatureimgName = 'sign_'.uniqid() . '.png';
			$sign = $path.$signatureimgName;
			file_put_contents($sign, $signatureimg);
			}
			//file_put_contents($file, $imageBase);
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/$orderid",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['status'=>'error','message'=>$err]);
			}else{
				$currentDatetime  = gmdate('c');
				$orderdata = json_decode($response,true);
				$orderId = $orderdata['id'];
				$orderReference = $orderdata['reference'];
				$memberId = $orderdata['memberId'];
				$memberEmail = $orderdata['memberEmail'];
				$stage = 'Dispatched';
				$invoiceDate = $currentDatetime;
				$dispatchedDate = $currentDatetime;
				$orderData = array();
				$orderData[] = array('id'=>$orderId,'reference'=>$orderReference,'memberId'=>$memberId,'memberEmail'=>$memberEmail,'status'=>'APPROVED','stage'=>$stage,'invoiceDate'=>$invoiceDate,'dispatchedDate'=>$dispatchedDate);
				$finalOrderData =  json_encode($orderData,true);
				$curl = curl_init();
				curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders?loadboms=%7Bloadboms%7D",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "PUT",
				CURLOPT_POSTFIELDS => $finalOrderData,
				CURLOPT_HTTPHEADER => array(
				"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi",
				"content-type: application/json"),
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);
				if ($err) {
					$result->setData(['status'=>'error','message'=>$err]);
				} else {
				$finalresponse = json_decode($response,true);
				if($finalresponse[0]['success']==1){
					foreach ($deliverdockets as $dispatched) {
						$dispatched->setOrderId($orderid);
						$dispatched->setReferenceNo($referenceno);
						$dispatched->setTotalAmount($totalAmount);
						$dispatched->setCompanyName($company);

						$dispatched->setCustomerFirstname($customerFirstname);
						$dispatched->setEmail($email);
						$dispatched->setContactNumber($contactNumber);
						$dispatched->setCustomerLastname($customerLastname);
						$dispatched->setDriverId($driverid);
						$dispatched->setDriverName($driverName);

						$dispatched->setStage($stage);
						$dispatched->setDispatchedtime($dispatchedtime);
						$dispatched->setAddress($address);
						$dispatched->setDocketImg($finalFilename);
						$dispatched->setSignature($signatureimgName);
						$dispatched->setComments($comments);
						$dispatched->setStatus('1');
						# code...
					}
					
					$deliverdockets->save();
					$cofirmationorder = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations')->load($orderid,'orderid');
					$cofirmationorder->setDriverName($driverid);
					$cofirmationorder->setStatus('Dispatched');
					$cofirmationorder->save();
					$result->setData(['status'=>'success','message'=>'Success fully Dispatched..']);
				}
				}
			}
		}else{
			$dispatchedtime  = gmdate('c');
			$referenceno = $this->getRequest()->getParam('reference_no');
			$customerFirstname = $this->getRequest()->getParam('customer_firstname');
			$customerLastname = $this->getRequest()->getParam('customer_lastname');
			$stage = $this->getRequest()->getParam('stage');
			$address = $this->getRequest()->getParam('address');
			$docketimg = $this->getRequest()->getParam('docket_img');
			$driverid = $this->getRequest()->getParam('driver_id');
			$dispatched = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Deliverydockets');
			$path = $this->_mediaDirectory->getAbsolutePath('mobiledata/');

			$signature = $this->getRequest()->getParam('signature');
			$totalAmount = $this->getRequest()->getParam('total_amount');
			$contactNumber = $this->getRequest()->getParam('contact_number');
			$email = $this->getRequest()->getParam('email');
			$comments = $this->getRequest()->getParam('comments');
			$company = $this->getRequest()->getParam('company');
			$driverName = $this->getRequest()->getParam('driver_name');
			$docketimages = json_decode($docketimg,true);
			if(!empty($docketimages)){
			foreach ($docketimages as $docketimg1) {
			$imageBase = base64_decode($docketimg1);
			$filname = uniqid() . '.png';
			$file = $path.$filname;
			$fname[] = $filname;
			file_put_contents($file, $imageBase);
			}
			$finalFilename = implode("@", $fname);
			}else{
				$finalFilename='';
			}
			if(!empty($signature)){
			$signatureimg = base64_decode($signature);
			$signatureimgName = 'sign_'.uniqid() . '.png';
			$sign = $path.$signatureimgName;
			file_put_contents($sign, $signatureimg);
			}
			//file_put_contents($file, $imageBase);
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/$orderid",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['status'=>'error','message'=>$err]);
			}else{
				$currentDatetime  = gmdate('c');
				$orderdata = json_decode($response,true);
				$orderId = $orderdata['id'];
				$orderReference = $orderdata['reference'];
				$memberId = $orderdata['memberId'];
				$memberEmail = $orderdata['memberEmail'];
				$stage = 'Dispatched';
				$invoiceDate = $currentDatetime;
				$dispatchedDate = $currentDatetime;
				$orderData = array();
				$orderData[] = array('id'=>$orderId,'reference'=>$orderReference,'memberId'=>$memberId,'memberEmail'=>$memberEmail,'status'=>'APPROVED','stage'=>$stage,'invoiceDate'=>$invoiceDate,'dispatchedDate'=>$dispatchedDate);
				$finalOrderData =  json_encode($orderData,true);
				$curl = curl_init();
				curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders?loadboms=%7Bloadboms%7D",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "PUT",
				CURLOPT_POSTFIELDS => $finalOrderData,
				CURLOPT_HTTPHEADER => array(
				"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi",
				"content-type: application/json"),
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);
				if ($err) {
					$result->setData(['status'=>'error','message'=>$err]);
				} else {
				$finalresponse = json_decode($response,true);
				if($finalresponse[0]['success']==1){
					$dispatched->setOrderId($orderid);
					$dispatched->setReferenceNo($referenceno);
					$dispatched->setTotalAmount($totalAmount);
					$dispatched->setCompanyName($company);
						
					$dispatched->setCustomerFirstname($customerFirstname);
					$dispatched->setEmail($email);
					$dispatched->setContactNumber($contactNumber);
					$dispatched->setCustomerLastname($customerLastname);
					$dispatched->setDriverId($driverid);
					$dispatched->setDriverName($driverName);
					
					$dispatched->setStage($stage);
					$dispatched->setDispatchedtime($dispatchedtime);
					$dispatched->setAddress($address);
					$dispatched->setDocketImg($finalFilename);
					$dispatched->setSignature($signatureimgName);
					$dispatched->setComments($comments);
					$dispatched->setStatus('1');
					$dispatched->save();
					$cofirmationorder = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations')->load($orderid,'orderid');
					$cofirmationorder->setDriverName($driverid);
					$cofirmationorder->setStatus('Dispatched');
					$cofirmationorder->save();
					$result->setData(['status'=>'success','message'=>'Success fully Dispatched..']);
				}
				}
			}
			
			//$result->setData(['status'=>'success','message'=>'Success fully Dispatched..']);

		}				
		

		return $result;

}
}