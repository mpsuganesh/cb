<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Countrylist extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_storeManager;
	protected $_countryCollectionFactory;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Directory\Model\ResourceModel\Country\CollectionFactory $_countryCollectionFactory,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->_storeManager = $storeManager;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_countryCollectionFactory = $_countryCollectionFactory;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$result = $this->resultJsonFactory->create();
		$countryCollection = $this->_countryCollectionFactory->create();
        $countryCollection->addFieldToSelect('*');

        foreach($countryCollection as $country){
        	$data[] = array('country_name'=>$country->getName());
        	//echo $country->getName();

        }
        $result->setData(['countrylist' => $data]);
        return $result;
	}
}
