<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Deliverydokets extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $_storeManager;
	protected $request;
	protected $_deliverydockets;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Cbhardware\Drivermanagement\Model\DeliverydocketsFactory $_deliverydockets)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_storeManager = $storeManager;
		$this->_deliverydockets = $_deliverydockets;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$driver_id = $this->getRequest()->getParam('driver_id');
		$accountType = $this->getRequest()->getParam('account_type');
		$pageLimit = 50;
		$page = $this->request->getParam('page');
		$finalpage = ($page-1)*$pageLimit;
		$deliverdockets = $this->_deliverydockets->create()->getCollection()->addFieldToFilter('driver_id', $driver_id);
		$deliverdockets->getSelect()->limit($pageLimit,$finalpage);
		$deliverdockets->setOrder('id','DESC');

		$deliverdocketData =  $deliverdockets->getData();
		$data  = array();
		$customerData = [];
		$result = $this->resultJsonFactory->create();
		if(count($deliverdocketData)>0&&empty($accountType)){
			foreach ($deliverdockets as $dockets){
				$img  = array();
				$docketOrderReference = $dockets->getReferenceNo();
				$customername = $dockets->getCustomerFirstname().$dockets->getCustomerLastname();
				$Stage = $dockets->getStage();
				$address = $dockets->getAddress();
				$docket_img = $dockets->getDocketImg();
				$docketTime = $dockets->getDispatchedtime();
				$driverName = $dockets->getDriverName();
				$comment = $dockets->getComments();
				$orderId = $dockets->getOrderId();
				if (strpos($docket_img, '@') !== false) {
					$imgExplode = explode('@', $docket_img);
					foreach ($imgExplode as $image) {
						$img[] = $this->_storeManager->getStore()->getBaseUrl().'pub/media/mobiledata/'.$image;
					}
				}else{
					if(empty($docket_img)){
					$img = array();
					}else{
						$img[] = $this->_storeManager->getStore()->getBaseUrl().'pub/media/mobiledata/'.$docket_img;	
					}
				}
 				$data[] = array('orderid'=>$orderId,
 					'orderreference'=>$docketOrderReference,
					'customername'=>$customername,
					'address'=>$address,
					'stage'=>$Stage,
					'dockettime'=>$docketTime,
					'drivername'=>$driverName,
					'comment'=>$comment,
					'image'=>$img);
				$result->setData(['DeliveryDocketes' => $data,'staus'=>'ok','page'=>'yes']);
			}
		}else{
			
			if($accountType=='owner'){
			$deliverdockets = $this->_deliverydockets->create()->getCollection();
			$deliverdockets->setOrder('id','DESC');
			foreach ($deliverdockets as $dockets){
				$img  = array();
				$docketOrderReference = $dockets->getReferenceNo();
				$customername = $dockets->getCustomerFirstname();
				$Stage = $dockets->getStage();
				$address = $dockets->getAddress();
				$docket_img = $dockets->getDocketImg();
				$docketTime = $dockets->getDispatchedtime();
				$driverName = $dockets->getDriverName();
				$comment = $dockets->getComments();
				$orderId = $dockets->getOrderId();
				if (strpos($docket_img, '@') !== false) {
					$imgExplode = explode('@', $docket_img);
					foreach ($imgExplode as $image) {
						$img[] = $this->_storeManager->getStore()->getBaseUrl().'pub/media/mobiledata/'.$image;
					}
				}else{
					if(empty($docket_img)){
					$img = array();
					}else{
						$img[] = $this->_storeManager->getStore()->getBaseUrl().'pub/media/mobiledata/'.$docket_img;	
					}
				}
 				$data[] = array('orderid'=>$orderId,
 					'orderreference'=>$docketOrderReference,
					'customername'=>$customername,
					'address'=>$address,
					'stage'=>$Stage,
					'dockettime'=>$docketTime,
					'drivername'=>$driverName,
					'comment'=>$comment,
					'image'=>$img);
			}
				
				$dataCount = count($data);
				if($dataCount > 49){
					$result->setData(['DeliveryDocketes' => $data,'staus'=>'ok','page'=>'yes']);
				}else{
					$result->setData(['DeliveryDocketes' => $data,'staus'=>'ok','page'=>'no']);
				}
				//print_r($data);
				//$co
			}else{

			$result->setData(['status'=>'ok','page'=>'no']);
			}
		}
		//exit();
		return $result;

	}
}
