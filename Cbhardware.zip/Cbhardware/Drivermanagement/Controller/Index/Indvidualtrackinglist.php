<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\IndividultrackingFactory;
class Indvidualtrackinglist extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $_drivermanagement;
    protected $resultJsonFactory; 
    protected $request;
    protected $_yardtask;
    protected $_individultracking;

    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Cbhardware\Drivermanagement\Model\IndividultrackingFactory $_individultracking,
        \Magento\Framework\App\Request\Http $request
    )
    {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_pageFactory = $pageFactory;
        $this->_individultracking = $_individultracking;
        $this->request = $request;
        return parent::__construct($context);
        
    }

    public function execute()
    {
        $result = $this->resultJsonFactory->create();
        $driverId = $this->getRequest()->getParam('driver_id');
        $invidualTraking = $this->_individultracking->create()->getCollection()->addFieldToFilter('driver_id',$driverId);
        $invidualTraking->getSelect()->limit(10,0);
        $invidualTraking->setOrder('id','DESC');

        $data = array();
        if(!empty($invidualTraking)){
		foreach ($invidualTraking as $trackingData) {
			$data[] = array('driver_id'=>$trackingData->getDriverId(),
				'drivername'=>$trackingData->getDriverName(),
				'latitude'=>$trackingData->getLatitude(),
				'longtitude'=>$trackingData->getLongtitude()
			);
		}
		$result->setData(['status'=>'success','trackingdata'=>$data]);
        }else{
        	 $result->setData(['status'=>'error','message'=>'invalid data']);
        }
		return $result;

        
        
    }
}