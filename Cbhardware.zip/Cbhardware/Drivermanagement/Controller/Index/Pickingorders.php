<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Pickingorders extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $salesorderconfirmations;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Salesorderconfirmations\Collection $salesorderconfirmations,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->salesorderconfirmations = $salesorderconfirmations;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$pageLimit = 50;
		$page = $this->request->getParam('page');
		$finalpage = ($page-1)*$pageLimit;
		$pickingmodel = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations');
        $collection = $pickingmodel->getCollection()->addFieldToFilter('stage', 'confirmed');
        $collection->getSelect()->limit($pageLimit,$finalpage);
        $collection->setOrder('id','DESC');
       	$data=array();
		$pickingorders =  $collection->getData();
		if(!empty($pickingorders)){
		foreach ($pickingorders as $pickingordersDetails) {
			$orderid = $pickingordersDetails['orderid'];
			$orderType = $pickingordersDetails['order_type'];
			if(!empty($orderid)&&!empty($orderType)&&$orderType=='sales'){
				$searchData = rawurlencode("id=$orderid AND status='APPROVED' AND stage='Release To Pick'");
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/?where=$searchData",
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => "",
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 30,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => "GET",
					CURLOPT_HTTPHEADER => array(
						"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
					),
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);
				if ($err) {
					echo "cURL Error #:" . $err;
				}else{
					$pickingordersDetail = json_decode($response,true);
					//print_r($pickingordersDetail);
					//exit();
					if(!empty($pickingordersDetail)){
						//print_r($pickingordersDetail);
						foreach ($pickingordersDetail as $keys=>$picking) {
						//$checkData[]=$keys;
						$data[] = array('order_type'=>$orderType,
							'order_id'=>$picking['id'],
							'createdDate'=>$picking['createdDate'],
							'reference'=>$picking['reference'],
							'total'=>$picking['total'],
							'status' =>$picking['status'],
							'stage'=>$picking['stage'],
							'company'=>$picking['company'],
							'estimatedDeliveryDate'=>$picking['estimatedDeliveryDate'],
							'projectname'=>$picking['projectName'],
							'trackingCode'=>$picking['trackingCode'],
							'email'=>$picking['email']
						);
					}
						
					//exit();
				}

				}
			}
			//echo $response;
			# code...
		}
		//echo count($checkData);
		//exit();
		if(count($data)>0){
			$result = $this->resultJsonFactory->create();
			$totalCount = count($data);
			if($totalCount>49){
			$result->setData(['pickingorders' => $data,'page'=>'yes']);
			}else{
				$result->setData(['pickingorders' => $data,'page'=>'no']);
			}

		}else{
			$result = $this->resultJsonFactory->create();
			$result->setData(['page'=>'no','status'=>'error','message'=>'there is no data found']);
		}
		//exit();
		return $result;
	}else{
		$result = $this->resultJsonFactory->create();
		$result->setData(['page'=>'no','status'=>'error','message'=>'there is no data found']);
		return $result;
		//return $result;
	}
		

	}
}