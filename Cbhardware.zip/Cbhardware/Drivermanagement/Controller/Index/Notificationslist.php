<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Notificationslist extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $salesorderconfirmations;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Salesorderconfirmations\Collection $salesorderconfirmations,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->salesorderconfirmations = $salesorderconfirmations;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		//echo "test";
		$result = $this->resultJsonFactory->create();
		$driverid = $this->request->getParam('driverid');
		$notificationsList = $this->salesorderconfirmations->addFieldToFilter('driver_name', $driverid)->addFieldToFilter('read_status','no')->addFieldToFilter('stage','assigned');
		//$listData[] = array();
		$totalCount = count($notificationsList->getData());
		if($totalCount>0){

		foreach ($notificationsList as $notification) {
			$listData[] = array('id'=>$notification->getId(),'order_id'=>$notification->getOrderid(),'stage'=>$notification->getStage(),'notification_title'=>$notification->getNotificationTitle(),'notification_msg'=>$notification->getNotificationMsg());
			# code...
		}
		$result->setData(['notificationslist' => $listData,'totalcount'=>$totalCount]);
		}else{
			$result->setData(['status' => 'error','message'=>'there is no data found']);
		}
       return $result;	
	}
}