<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Salesorderhistroy extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		
		$page = $this->request->getParam('page');
		$data = array();
		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/?where=stage='Dispatched'&order=CreatedDate%20DESC&page=$page&rows=50",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
		"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
		),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		echo "cURL Error #:" . $err;
		} else {
		$salesorders = json_decode($response,true);
		$salesordersData = [];
		if(!empty($salesorders)){
		foreach ($salesorders as $sales) {
			$salesordersData['status'] ="success";
			$salesordersData['code'] ="200";
			$data[] = array('orde_id'=>$sales['id'],
				'createdDate'=>$sales['createdDate'],
				'reference'=>$sales['reference'],
				'total'=>$sales['total'],
				'status' =>$sales['status'],
				'stage'=>$sales['stage'],
				'company'=>$sales['company'],
				'estimatedDeliveryDate'=>$sales['estimatedDeliveryDate'],
				'projectname'=>$sales['projectName'],
				'trackingCode'=>$sales['trackingCode'],
				'email'=>$sales['email']
			);
			//echo "<pre>";
			//print_r($sales);
			# code...
		//$salesordersData[]= $data;
		$result = $this->resultJsonFactory->create();
		$result->setData(['Details' => $data,
			'page'=>'yes']);
		}
		return $result;
		}else{
		$result = $this->resultJsonFactory->create();
		$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
		return $result;
		}
		//print_r($data);
		/*$result2 = $this->resultJsonFactory->create();
		$result2->setData(['Details' => $data]);
		return $result2;*/
		}
				
	}
}