<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Assigndriver extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $salesorderconfirmations;
	protected $_mediaDirectory;
	protected $_pushnotiofications;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Salesorderconfirmations\Collection $salesorderconfirmations,
		\Magento\Framework\Filesystem $filesystem,
		\Cbhardware\Pushnotifications\Model\PushnotificationsFactory $_pushnotiofications,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
		$this->salesorderconfirmations = $salesorderconfirmations;
		$this->_pushnotiofications = $_pushnotiofications;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		
		$orderid = $this->request->getParam('orderid');
		$driverid = $this->request->getParam('driverid');
		$assignDriver = $this->request->getParam('assign_driver');
		$adminName = $this->request->getParam('name');
		$comments = $this->request->getParam('comments');
		$signature = $this->request->getParam('signature');
		$lineItems = json_decode($this->request->getParam('lineItems'),true);
		$datetime = date('d-m-Y H:i:s');
		$path = $this->_mediaDirectory->getAbsolutePath('mobiledata/');
		//echo $datetime;
		//exit();
		//print_r($lineItems);
		
		if(!empty($orderid)&&(!empty($driverid))){
			$result = $this->resultJsonFactory->create();
			$confirmationorder = $this->salesorderconfirmations->addFieldToFilter('orderid', $orderid);
			$existsdata = $confirmationorder->getData();
			if(count($existsdata)>0){
				$status['status'] ="Successfully assigned to driver";
				$status['code'] ="200";
				$confirmationorder = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations')->load($orderid,'orderid');
				$confirmationorder->setOrderid($orderid);
				$confirmationorder->setDriverName($driverid);
				$confirmationorder->setStage('assigned');
				$confirmationorder->setName($adminName);
				$confirmationorder->setAssignDriver($assignDriver);
				$confirmationorder->setComments($comments);
				$confirmationorder->setDate($datetime);
				// save signature
				if(!empty($signature)){
				$signatureimg = base64_decode($signature);
				$signatureimgName = 'sign_'.uniqid() . '.png';
				$sign = $path.$signatureimgName;
				file_put_contents($sign, $signatureimg);
				}
				$confirmationorder->setSignature($signatureimgName);
				// end of save singnature
				//echo $comments;
		//exit();
				// sales oreder qty update to cin7
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/$orderid",
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => "",
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 30,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => "GET",
					CURLOPT_HTTPHEADER => array(
						"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
					),
				));

				$response = curl_exec($curl);
				$err = curl_error($curl);

				curl_close($curl);

				if ($err) {
					$result->setData(['status'=>'error','message'=>$err]);
				}else{
					$orderDetails = json_decode($response,true);
				// send pusnotification 
					$pushnotiofications = $this->_pushnotiofications->create()->getCollection();
					$pushData = $pushnotiofications->getData();

					$loginDetails = $this->_mobileapi->create()->getCollection()->addFieldToFilter('id',array('eq'=>$driverid));
					//print_r($loginDetails->getData());
					//exit();
					$secretKey = $pushData[0]['secret_key'];
					$filePath  = $pushData[0]['file_name'];
					$messageTitle = $pushData[0]['msg_title'];
					$messageDesc = strip_tags($pushData[0]['msg_desc']);

					if($pushData[0]['status']=="test"&&$pushData[0]['active']=="yes"){
						$loginData = $loginDetails->getData();
						$deviceToken = $loginData[0]['device_token'];
						$gatewayUrl = $pushData[0]['gateway_url_test'];

						if(!empty($deviceToken)){
							$ctx = stream_context_create();
							stream_context_set_option($ctx, 'ssl', 'local_cert', 'pub/media/'.$filePath);
							stream_context_set_option($ctx, 'ssl', 'passphrase', $secretKey);
							$fp = stream_socket_client($gatewayUrl, $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
							if (!$fp)
								$result->setData(['status'=>'success','message'=>'Failed to connect']);
								//exit("Failed to connect: $err $errstr" . PHP_EOL);
							$body['aps'] = array(
								'alert' => array(
									'title' => $messageTitle,
									'body' => $messageDesc,
								),
								'sound' => 'default'
							);
							$confirmationorder->setNotificationTitle($messageTitle);
							$confirmationorder->setNotificationMsg($messageDesc);
							$confirmationorder->setReadStatus('no');
							$payload = json_encode($body);
							$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
							$result1 = fwrite($fp, $msg, strlen($msg));
							fclose($fp);
							
							$result->setData(['status'=>'success','message'=>'Successfully assigned to driver.']);
							$confirmationorder->save();
						}else{
							$result->setData(['status'=>'success','message'=>'Successfully assigned to driver.']);
							$confirmationorder->save();
						}
					}else{
						if($pushData[0]['status']=="live"&&$pushData[0]['active']=="yes"){
							$loginData = $loginDetails->getData();
							$deviceToken = $loginData[0]['device_token'];
							$gatewayUrl = $pushData[0]['gateway_url_live'];

							if(!empty($deviceToken)){
							$ctx = stream_context_create();
							stream_context_set_option($ctx, 'ssl', 'local_cert', 'pub/media/'.$filePath);
							stream_context_set_option($ctx, 'ssl', 'passphrase', $secretKey);
							$fp = stream_socket_client($gatewayUrl, $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
							if (!$fp)
							$result->setData(['status'=>'success','message'=>'Failed to connect']);
							//exit("Failed to connect: $err $errstr" . PHP_EOL);
							$body['aps'] = array(
							'alert' => array(
								'title' => $messageTitle,
								'body' => $messageDesc,
							),
							'sound' => 'default'
							);
							$confirmationorder->setNotificationTitle($messageTitle);
							$confirmationorder->setNotificationMsg($messageDesc);
							$confirmationorder->setReadStatus('no');
							$payload = json_encode($body);
							$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
							$result1 = fwrite($fp, $msg, strlen($msg));
							fclose($fp);
								
							$result->setData(['status'=>'success','message'=>'Successfully assigned to driver.']);
							$confirmationorder->save();
							}else{
							$result->setData(['status'=>'success','message'=>'Successfully assigned to driver.']);
							$confirmationorder->save();
							}

						}
						//$result->setData(['status'=>'success','message'=>'Successfully assigned to driver.']);
						//$cofirmationorder->save();
					}
				// end send push notifications
					/*if(!empty($lineItems)){
					foreach ($lineItems as $key => $received) {
							$finalLineItem[] =$received;
					}
					}else{
						$finalLineItem[]=array('id'=>$line['id'],'qty'=>0);
					}
				$currentDatetime  = gmdate('c');
				$orderData[] = array('id'=>$orderid,'lineItems'=>$finalLineItem);
				$finalOrderdata = json_encode($orderData,true);	
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/?loadboms=%7Bloadboms%7D",
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => "",
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 30,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => "PUT",
					CURLOPT_POSTFIELDS => $finalOrderdata,
					CURLOPT_HTTPHEADER => array(
						"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi",
						"content-type: application/json"
					),
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);
				if ($err) {
					$result->setData(['status'=>'error','message'=>$err]);
				} else {
					$finalresponse = json_decode($response,true);
					if($finalresponse[0]['success']==1){
					}
				}*/
				
			}
						//$cofirmationorder->save();
				// end sales order qty update to cin7
				//$result->setData(['status'=>'success','message'=>'Success fully assigned driver.']);

		}else{

			$status['status'] ="error";
			$status['message'] = "error";
			$status['code'] ="200";
			$result->setData(['confirmedstatus' => $status]);
		}
	}
		//
	return $result;

       //die('test');		
}
}