<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Yardtaskdelete extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_yardtask;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Cbhardware\Drivermanagement\Model\YardtaskFactory $_yardtask)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_yardtask = $_yardtask;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		//echo "test";
		$id = $this->getRequest()->getParam('id');
		$driver_id = $this->getRequest()->getParam('driver_id');
		$list = $this->getRequest()->getParam('list');
		$result = $this->resultJsonFactory->create();
		if(!empty($id)&&!empty($driver_id)&&empty($list)){
			$yardtask = $this->_yardtask->create()->getCollection()->addFieldToFilter('id', $id);
			$datacheck  =$yardtask->getData();
			if(!empty($datacheck)){
				$model = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Yardtask');
				$model->load($id);
				$model->delete();
				$date = date('Y-m-d');
				$yardtasklist = $this->_yardtask->create()->getCollection()->addFieldToFilter('driver_id', $driver_id)->addFieldToFilter('date',$date);
				$datacheck  =$yardtasklist->getData();
				if(!empty($datacheck)){
				foreach ($yardtasklist as  $tasklist){
				$taskdriverid = $tasklist->getDriverId();
				$id = $tasklist->getId();
				//echo $driverid;
				$task = $tasklist->getYardtask();
				$data[] =array('id'=>$id,'driver_id'=>$driver_id,'task'=>$task);
				}
				$result->setData(['status'=>'success','message'=>'Success fully Deleted','yardtasklist'=>$data]);
				}else{
					$result->setData(['status'=>'error','message'=>'there is no data found']);
				}
			}else{
				$result->setData(['status'=>'error','message'=>'there is no data found']);
			}
		}else{
			if(!empty($id)&&!empty($driver_id)&&!empty($list)){
				$model = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Yardtask');
				$model->load($id);
				$model->delete();
				$pageLimit = 50;
				$page = ($this->getRequest()->getParam('page'))-1;
				$finalpage = ($page-1)*$pageLimit;
				$result = $this->resultJsonFactory->create();
				if(!empty($driver_id)&&!empty($page)){
				$yardtask = $this->_yardtask->create()->getCollection();
				$yardtask->getSelect()->limit($pageLimit,$finalpage);
				$data = array();
				$datacheck  =$yardtask->getData();
				if(!empty($datacheck)){
				foreach ($yardtask as  $tasklist){
				$driverid = $tasklist->getDriverId();
				$id = $tasklist->getId();
				//echo $driverid;
				$yardtask = $tasklist->getYardtask();
				$data[] =array('id'=>$id,'driver_id'=>$driver_id,'task'=>$yardtask);
				# code...
				}
				//$result->setData(['yardtasklist'=>$data,'status'=>'success','page'=>'yes']);
				

				$result->setData(['status'=>'success','message'=>'Success fully Deleted','yardtasklist'=>$data]);
				}else{
				$result->setData(['status'=>'success','page'=>'no']);	
				} 

				}else{
				$result->setData(['status'=>'error','page'=>'no']);
				}
			}else{

			$result->setData(['status'=>'error','message'=>'error']);
			}
		}
		return $result;
		
		//print_r($yardtask->getData());

	}
}
