<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Forklifsave extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_yardtask;
	protected $logger;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Psr\Log\LoggerInterface $logger,
		\Magento\Framework\App\Request\Http $request
	)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->logger = $logger;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		//$this->logger->debug("test");
		//$this->logger->info('info1234'); 
		$forklift = $this->getRequest()->getParam('forklift');
		$day = $this->getRequest()->getParam('day');
		$date = $this->getRequest()->getParam('date');
		$drivername = $this->getRequest()->getParam('deriver_name');
		$driver_id = $this->getRequest()->getParam('driver_id');
		$model_type = $this->getRequest()->getParam('model_type');
		$name = $this->getRequest()->getParam('name');
		$comment = $this->getRequest()->getParam('comment');
		$supervisorName = $this->getRequest()->getParam('supervisor_name');
		$result = $this->resultJsonFactory->create();
		if(!empty($forklift)&&!empty($date)&&!empty($day)&&!empty($drivername)&&!empty($driver_id)){
			$newPhrase = stripcslashes(str_replace('\n', '', $forklift));
			$forkliftData = json_decode($newPhrase,true);
			$Forklift = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Forklift')->getCollection()->addFieldToFilter('date',array('eq'=>$date))->addFieldToFilter('driver_id',array('eq'=>$driver_id))->addFieldToFilter('model_type',array('eq'=>$model_type));
			$existsData = $Forklift->getData();
			if(!empty($existsData)){
				$result->setData(['status'=>'error','message'=>'this data already exists']);
			}else{
				foreach ($forkliftData as $fork) {
				$Forklift = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Forklift');
				$Forklift->setDriverId($driver_id);
				$Forklift->setDeriverName($drivername);
				$Forklift->setTitle($fork['titte']);
				$Forklift->setDescriptions($fork['descriptions']);
				$Forklift->setDate($date);
				$Forklift->setDay($day);
				$Forklift->setStatus($fork['status']);
				$Forklift->setModelType($model_type);
				$Forklift->setComment($comment);
				$Forklift->setName($name);
				$Forklift->setSupervisorName($supervisorName);
				$Forklift->save();
				$result->setData(['status'=>'success','message'=>'Success fully saved..']);
				//echo $fork['driver_name'];
			}
			}
			//echo $Forklift->getSelect();
			//exit();
			
		}else{
			$result->setData(['status'=>'error','message'=>'invalid data']);
		}
			
		
		return $result;	
		//echo $forklift;
		//echo "test";
		
		
	}
}
