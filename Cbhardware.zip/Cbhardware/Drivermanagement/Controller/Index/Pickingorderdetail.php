<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Pickingorderdetail extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $salesorderconfirmations;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Salesorderconfirmations\Collection $salesorderconfirmations,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->salesorderconfirmations = $salesorderconfirmations;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$orderid = $this->request->getParam('orderid');
		$ordertype = $this->request->getParam('order_type');
		
		if(!empty($orderid)&&!empty($ordertype)){
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/$orderid",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
				echo "cURL Error #:" . $err;
			}else{
				$salesordersDetail = json_decode($response,true);
				$salesordersData = [];
				if(!empty($salesordersDetail)){
					
					// get create by 
					$createdBy = $salesordersDetail['createdBy'];
					$curl = curl_init();
					curl_setopt_array($curl, array(
						CURLOPT_URL => "https://api.cin7.com/api/v1/Users/$createdBy",
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => "",
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 30,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => "GET",
						CURLOPT_HTTPHEADER => array(
							"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"),
					));

					$createdBy = curl_exec($curl);
					$err = curl_error($curl);

					curl_close($curl);

					if ($err) {
						echo "cURL Error #:" . $err;
					} else {
						$userDetails = json_decode($createdBy,true);
						if(!empty($userDetails)){
							$createdUser = $userDetails['firstName'].' '.$userDetails['lastName'];
						}else{
							$createdUser = '';
						}
					}
					// get all driver
					$driveraccountdetails = $this->_mobileapi->create()->getCollection()->addFieldToFilter('driver_details',array('neq'=>0));
					$driverData =  $driveraccountdetails->getData();
					foreach($driverData as $driverDetails){
						$drivers[] = array('driverid'=>$driverDetails['id'],
							'drivername'=>$driverDetails['name']);
					}
					//print_r($driveraccountdetails->getData());
					//exit();
					// end prem
					if(!empty($salesordersDetail['lineItems'])){
					foreach ($salesordersDetail['lineItems'] as $lineItems) {
						$productId = $lineItems['productId'];
						$curl = curl_init();
						curl_setopt_array($curl, array(
							CURLOPT_URL => "https://api.cin7.com/api/v1/Products/$productId",
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_ENCODING => "",
							CURLOPT_MAXREDIRS => 10,
							CURLOPT_TIMEOUT => 30,
							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							CURLOPT_CUSTOMREQUEST => "GET",
							CURLOPT_HTTPHEADER => array(
								"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"),
						));

						$productimg = curl_exec($curl);
						$productimages = json_decode($productimg,true);
						$productimagesck = $productimages['images'];
						if(count($productimagesck)>0){
							//$proimg = $productimages['images'][0]['link'];
							if(!empty($productimages['productOptions'][0]['image'])){
								$proimg = $productimages['productOptions'][0]['image']['link'];
							}else{

							$proimg = $productimages['images'][0]['link'];
							}
						}else{
							$proimg = '';
						}
						$err = curl_error($curl);

						curl_close($curl);
						$productDetails[] = array('name'=>$lineItems['name'],
							'id'=>$lineItems['id'],
							'code'=>$lineItems['code'],
							'qty'=>$lineItems['qty'],
							'uinitprice'=>$lineItems['unitPrice'],
							'discount'=>$lineItems['discount'],
							'stockAvailable'=>$productimages['productOptions'][0]['stockAvailable'],
							'productTotalprice'=>($lineItems['qty']*$lineItems['unitPrice'])-($lineItems['discount']),
							'stockOnHand' =>$productimages['productOptions'][0]['stockOnHand'],
							'productimage'=>$proimg,
						);
							# code...
					}
					}else{
						$productDetails=array();
					}
					// end get product details
					if(!empty($salesordersDetail['mobile'])){
						$phoneNumber = $salesordersDetail['mobile'];
					}else{
						$phoneNumber = $salesordersDetail['phone'];
					}

					$data[] = array('order_type'=>'sales',
						'order_id'=>$salesordersDetail['id'],
						'customername'=>$salesordersDetail['firstName'].' '.$salesordersDetail['lastName'],
						'reference'=>$salesordersDetail['reference'],
						'email'=>$salesordersDetail['email'],
						'createdBy'=>$createdUser,
						'mobile' =>$phoneNumber,
						'createdDate'=>$salesordersDetail['createdDate'],
						'total'=>$salesordersDetail['total'],
						'deliveryAddress'=>$salesordersDetail['deliveryAddress1'].','.$salesordersDetail['deliveryAddress2'].','.$salesordersDetail['deliveryCity'].','.$salesordersDetail['deliveryState'].','.$salesordersDetail['deliveryPostalCode'].','.$salesordersDetail['deliveryCountry'],
						'billingAddress' =>$salesordersDetail['billingAddress1'].','.$salesordersDetail['billingAddress2'].','.$salesordersDetail['billingCity'].','.$salesordersDetail['billingPostalCode'].','.$salesordersDetail['billingState'].','.$salesordersDetail['billingCountry'],
						'status' =>$salesordersDetail['status'],
						'stage'=>$salesordersDetail['stage'],
						'company'=>$salesordersDetail['company'],
						'estimatedDeliveryDate'=>$salesordersDetail['estimatedDeliveryDate'],
						'projectname'=>$salesordersDetail['projectName'],
						'trackingCode'=>$salesordersDetail['trackingCode'],
						'productDetails'=>$productDetails,
						'deliveryInstructions'=>$salesordersDetail['deliveryInstructions']
					);	
					$result = $this->resultJsonFactory->create();

					$result->setData(['orderDetails' => $data,
						'driverdetails'=>$drivers]);
					
					//exit();
					return $result;
				}else{
					$result = $this->resultJsonFactory->create();
					$result->setData(['page' => 'no']);
					return $result;
				}

			}
		}
		//echo $orderid;
		//echo "test";
		//exit();
		//11554
		//return "test";
		
	}
}