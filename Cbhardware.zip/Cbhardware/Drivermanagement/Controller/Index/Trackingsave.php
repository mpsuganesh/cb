<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Trackingsave extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivertracking;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_individultracking;
	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\IndividultrackingFactory $_individultracking,
		\Cbhardware\Drivermanagement\Model\DrivertrackingFactory $_drivertracking)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivertracking = $_drivertracking;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		$this->_individultracking = $_individultracking;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$driverId = $this->getRequest()->getParam('driver_id');
		$driverTrackingDetails = $this->_drivertracking->create()->getCollection()->addFieldToFilter('driver_id',array('eq'=>$driverId));
		$latitude = $this->getRequest()->getParam('latitude');
		$longtitude = $this->getRequest()->getParam('longtitude');
		$driverName = $this->getRequest()->getParam('driver_name');
		$result = $this->resultJsonFactory->create();
		$date = date('Y-m-d');
		if(!empty($driverId)&&!empty($latitude)&&!empty($longtitude)&&!empty($date)){
			if(!empty($driverTrackingDetails->getData())){
				foreach ($driverTrackingDetails as $driverTracking) {
					$driverTracking->setDriverId($driverId);
					$driverTracking->setDriverName($driverName);
					$driverTracking->setLatitude($latitude);
					$driverTracking->setLongtitude($longtitude);
					$driverTracking->setDate($date);
				}
				$driverTracking->save();

				$invidualTraking = $this->_individultracking->create();
				$invidualTraking->setDriverId($driverId);
				$invidualTraking->setDriverName($driverName);
				$invidualTraking->setLatitude($latitude);
				$invidualTraking->setLongtitude($longtitude);
				$invidualTraking->save();

				$result->setData(['status'=>'success','message'=>'successfully saved']);
			}else{
				$driverTracking = $this->_drivertracking->create();
				$driverTracking->setDriverId($driverId);
				$driverTracking->setDriverName($driverName);
				$driverTracking->setLatitude($latitude);
				$driverTracking->setLongtitude($longtitude);
				$driverTracking->setDate($date);
				$driverTracking->save();

				$invidualTraking = $this->_individultracking->create();
				$invidualTraking->setDriverId($driverId);
				$invidualTraking->setDriverName($driverName);
				$invidualTraking->setLatitude($latitude);
				$invidualTraking->setLongtitude($longtitude);
				$invidualTraking->save();
				
				$result->setData(['status'=>'success','message'=>'successfully saved']);

			}
		}else{
			$result->setData(['status'=>'error','message'=>'invalid data']);
		}
		return $result;
	}
}
