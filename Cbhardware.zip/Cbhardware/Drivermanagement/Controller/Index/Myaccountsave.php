<?php

namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;

class Myaccountsave extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_storeManager;
	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Framework\Filesystem $filesystem,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->_storeManager = $storeManager;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$accountId = $this->getRequest()->getParam('account_id');
		$accountDetails = $this->getRequest()->getParam('accountdetails');
		$profileImage = $this->getRequest()->getParam('profile_img');
		$driverDetails = $this->getRequest()->getParam('driverdetails');
		$driveraccountdetails = $this->_mobileapi->create()->getCollection()->addFieldToFilter('id',array('eq'=>$accountId));
		$path = $this->_mediaDirectory->getAbsolutePath('myprofile/');
		$result = $this->resultJsonFactory->create();
		//echo $profileImage;
		//exit();
		$k2bDriverData = [];
		//print_r($driveraccountdetails->getData());
		//exit();
		$path1 = $this->_storeManager->getStore()->getBaseUrl().$this->_storeManager->getStore()->getBaseMediaDir()."/myprofile/";
		//echo $path1;
		$account = json_decode($accountDetails,true);
		//print_r($account);
		//exit();
		if(!empty($accountId)&&!empty($accountDetails)&&empty($driverDetails)){
			if(!empty($profileImage)){
				$imageBase = base64_decode($profileImage);
				$filname = uniqid() . '.png';
				$file = $path.$filname;
				file_put_contents($file, $imageBase);
				}else{
				$filname='';
				}
			//print_r($account);
			foreach ($driveraccountdetails as $accountdata) {
                    $accountdata->setName($account[0]["name"]);
                    $accountdata->setEmail($account[0]['email']);
                    $accountdata->setDob($account[0]['dob']);
                    $accountdata->setCountryId($account[0]['country_id']);
                    $accountdata->setStreetAddress($account[0]['street_address']);
                    $accountdata->setStreetAddressLine2($account[0]['street_address_line_2']);
                    $accountdata->setCity($account[0]['city']);
                    $accountdata->setState($account[0]['state']);
                    $accountdata->setPostalCode($account[0]['postal_code']);
                    $accountdata->setMobileNo($account[0]['mobile_no']);
                    //$accountdata->setMaritalStatus('marital_status');
                    $accountdata->setProfileImg($filname);

                }
                $driveraccountdetails->save();
                foreach ($driveraccountdetails as $accountdata) {
                	$data = array("id"=>$accountdata->getId(),
					"account"=>"Owner",
					"name"=>$accountdata->getName(),
					"email"=>$accountdata->getEmail(),
					"street_address"=>$accountdata->getStreetAddress(),
					"street_address_line_2"=>$accountdata->getStreetAddressLine2(),
					"city"=>$accountdata->getCity(),
					"country"=>$accountdata->getCountryId(),
					"state"=>$accountdata->getState(),
					"postalcode"=>$accountdata->getPostalCode(),
					"mobileno"=>$accountdata->getMobileNo(),
					"maritalStatus"=>$accountdata->getMaritalStatus(),
					"accountid"=>$accountdata->getDriverDetails(),
					"sales"=>$accountdata->getSales(),
					"picking"=>$accountdata->getPicking(),
					"purchase"=>$accountdata->getPurchase(),
					"vehicle"=>$accountdata->getVehicle(),
					"active"=>$accountdata->getActive(),
					"dob"=>$accountdata->getDob(),
					"profileimg"=>$path1.$accountdata->getProfileImg()
				);
				$k2bDriverData['accountdetails']= $data;
                	//echo $accountdata->getName();

                }
               //print_r($k2bDriverData);
                $result->setData(['Details' => $k2bDriverData,'status'=>'success','message'=>'Successfully updated']);

              // exit();
               // echo "success";

		}else{
			if(!empty($driverDetails)){
				$driverinformations = json_decode($driverDetails,true);
				if(!empty($profileImage)){
				$imageBase = base64_decode($profileImage);
				$filname = uniqid() . '.png';
				$file = $path.$filname;
				file_put_contents($file, $imageBase);
				}else{
				$filname='';
				}
				//print_r($driverinformations);
				foreach ($driveraccountdetails as $accountdata) {
                    $accountdata->setName($account[0]["driver_name"]);
                    $accountdata->setEmail($account[0]['email']);
                    $accountdata->setDob($account[0]['dob']);
                    $accountdata->setCountryId($account[0]['country_id']);
                    $accountdata->setStreetAddress($account[0]['street_address']);
                    $accountdata->setStreetAddressLine2($account[0]['street_address_line_2']);
                    $accountdata->setCity($account[0]['city']);
                    $accountdata->setState($account[0]['state']);
                    $accountdata->setPostalCode($account[0]['postal_code']);
                    $accountdata->setMobileNo($account[0]['mobile_number']);
                   // $accountdata->setMaritalStatus('marital_status');
                    $accountdata->setProfileImg($filname);
                    $driverId = $accountdata->getDriverDetails();
                    //echo $driverId;
                }
               	$driveraccountdetails->save();

               	foreach ($driveraccountdetails as $accountdata) {
                	$data = array("id"=>$accountdata->getId(),
					"account"=>"Driver",
					"name"=>$accountdata->getName(),
					"email"=>$accountdata->getEmail(),
					"street_address"=>$accountdata->getStreetAddress(),
					"street_address_line_2"=>$accountdata->getStreetAddressLine2(),
					"city"=>$accountdata->getCity(),
					"country"=>$accountdata->getCountryId(),
					"state"=>$accountdata->getState(),
					"postalcode"=>$accountdata->getPostalCode(),
					"mobileno"=>$accountdata->getMobileNo(),
					"maritalStatus"=>$accountdata->getMaritalStatus(),
					"accountid"=>$accountdata->getDriverDetails(),
					"sales"=>$accountdata->getSales(),
					"picking"=>$accountdata->getPicking(),
					"purchase"=>$accountdata->getPurchase(),
					"vehicle"=>$accountdata->getVehicle(),
					"active"=>$accountdata->getActive(),
					"dob"=>$accountdata->getDob(),
					"profileimg"=>$path1.$accountdata->getProfileImg()
				);
				$k2bDriverData['accountdetails']= $data;
                	//echo $accountdata->getName();

                }

               /* $driverData = $this->_drivermanagement->create()->getCollection()->addFieldToFilter('id',array('eq'=>$driverId));
                foreach ($driverData as $driverdetails) {
                	$driverdetails->setDriverName($driverinformations[0]['driver_name']);
                	$driverdetails->setMobileNumber($driverinformations[0]['mobile_number']);
                	//$driverdetails->setLicenceNumber($driverinformations['licence_number']);
                	$driverdetails->setLocations($driverinformations[0]['locations']);
                	$driverdetails->setExpireDate($driverinformations[0]['expire_date']);
                	
                }
                $driverData->save();*/

                /*foreach ($driverData as $finaldata){
					$licence = $finaldata->getLicenceNumber();
						$data = array("id"=>$finaldata->getId(),
						"drivername"=>$finaldata->getDriverName(),
						"email"=>$finaldata->getEmail(),
						"dob"=>$finaldata->getDob(),
						"licencenumber "=>$finaldata->getLicenceNumber(),
						"locations"=>$finaldata->getLocations()
					);
					$k2bDriverData['driverdetails']= $data;

				}*/

				$result->setData(['Details' => $k2bDriverData,'status'=>'success','message'=>'Successfully updated']);
                //print_r($driverData->getData());
                //echo "success";
                
                //echo $driverId;


			}

		}
		/*;*/

		return $result;

	}
}
