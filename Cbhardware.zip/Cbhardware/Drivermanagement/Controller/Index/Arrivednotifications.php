<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Arrivednotifications extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$customerPhone = $this->getRequest()->getParam('customer_phone');
		$result = $this->resultJsonFactory->create();
		if(!empty($customerPhone)){
			//echo $customerPhone;
			$massageData[] = array("delivery_report"=>"true","content"=>"Your order is on its way","destination_number"=>$customerPhone,"format"=>"SMS");
			$msg = array("messages"=>$massageData);
			$messages = json_encode($msg);
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => "http://api.messagemedia.com/v1/messages",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS =>$messages,
				CURLOPT_HTTPHEADER => array(
					"Accept: application/json",
					"Authorization: Basic a1hwOU1WMEE5Z3EwaE8xRnYzR0M6d29IVlN0WFhxYW51MnZqTFRhQ2hHbnZnU1haUjJn",
					"content-type: application/json"
				),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
				echo "cURL Error #:" . $err;
			} else {
				$result->setData(['status'=>'success','message'=>'Successfully send message']);
				//echo $response;
			}
			//echo json_encode($msg);
		}

		
		//echo $clientNumber;
		return $result;
	}
}
