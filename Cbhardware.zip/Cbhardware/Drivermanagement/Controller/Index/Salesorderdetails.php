<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Salesorderdetails extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_deliverydockets;
	protected $_storeManager;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Cbhardware\Drivermanagement\Model\DeliverydocketsFactory $_deliverydockets,
		\Magento\Store\Model\StoreManagerInterface $storeManager)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		$this->_deliverydockets = $_deliverydockets;
		$this->_storeManager = $storeManager;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$orderid = $this->request->getParam('orderid');
		if(!empty($orderid)){
			$curl = curl_init();

			curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/$orderid",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
				echo "cURL Error #:" . $err;
			}else{
				$salesordersDetail = json_decode($response,true);
				$salesordersData = [];
				if(!empty($salesordersDetail)){
					
					// get create by 
					$createdBy = $salesordersDetail['createdBy'];
					$curl = curl_init();
					curl_setopt_array($curl, array(
						CURLOPT_URL => "https://api.cin7.com/api/v1/Users/$createdBy",
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => "",
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 30,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => "GET",
						CURLOPT_HTTPHEADER => array(
							"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"),
					));

					$createdBy = curl_exec($curl);
					$err = curl_error($curl);

					curl_close($curl);

					if ($err) {
						echo "cURL Error #:" . $err;
					} else {
						$userDetails = json_decode($createdBy,true);
						if(!empty($userDetails)){
							$createdUser = $userDetails['firstName'].' '.$userDetails['lastName'];
						}else{
							$createdUser = '';
						}
					}
					// end of created by


					// get product details
						//print_r($salesordersDetail['lineItems']);
					if(!empty($salesordersDetail['lineItems'])){
					foreach ($salesordersDetail['lineItems'] as $lineItems) {
						$productId = $lineItems['productId'];
						$curl = curl_init();
						curl_setopt_array($curl, array(
							CURLOPT_URL => "https://api.cin7.com/api/v1/Products/$productId",
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_ENCODING => "",
							CURLOPT_MAXREDIRS => 10,
							CURLOPT_TIMEOUT => 30,
							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							CURLOPT_CUSTOMREQUEST => "GET",
							CURLOPT_HTTPHEADER => array(
								"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"),
						));

						$productimg = curl_exec($curl);
						$productimages = json_decode($productimg,true);
						$productimagesck = $productimages['images'];
						if(count($productimagesck)>0){
							//print_r($productimages['productOptions'][0]['image']);
							if(!empty($productimages['productOptions'][0]['image'])){
								$proimg = $productimages['productOptions'][0]['image']['link'];
							}else{

							$proimg = $productimages['images'][0]['link'];
							}
						}else{
							$proimg = '';
						}
						$err = curl_error($curl);

						curl_close($curl);
						$productDetails[] = array('name'=>$lineItems['name'],
							'code'=>$lineItems['code'],
							'qty'=>$lineItems['qty'],
							'qtyShipped'=>$lineItems['qtyShipped'],
							'uinitprice'=>$lineItems['unitPrice'],
							'discount'=>$lineItems['discount'],
							'stockAvailable'=>$productimages['productOptions'][0]['stockAvailable'],
							'stockOnHand' =>$productimages['productOptions'][0]['stockOnHand'],
							'productTotalprice'=>($lineItems['qty']*$lineItems['unitPrice'])-($lineItems['discount']),
							'productimage'=>$proimg,
						);
							# code...
					}
					}else{
						$productDetails = array();
					}
					//exit();
					// end get product details
					$deliverdockets = $this->_deliverydockets->create()->getCollection()->addFieldToFilter('order_id', $orderid);
					$dockets = $deliverdockets->getData();
					if(!empty($dockets)){
						//echo $dockets[0]['docket_img'];
					if (strpos($dockets[0]['docket_img'], '@') !== false) {
					$imgExplode = explode('@', $dockets[0]['docket_img']);
					foreach ($imgExplode as $image) {
					$img[] = $this->_storeManager->getStore()->getBaseUrl().'pub/media/mobiledata/'.$image;
					}
					}else{
					if(empty($dockets[0]['docket_img'])){
					$img = array();
					}else{
					$img[] = $this->_storeManager->getStore()->getBaseUrl().'pub/media/mobiledata/'.$dockets[0]['docket_img'];	
					}
					}
					}else{
						$img = "";
					}
					//print_r($img);
					//echo $deliverdockets->getDocketImg();
					//exit();


					if(!empty($salesordersDetail['mobile'])){
						$phoneNumber = $salesordersDetail['mobile'];
					}else{
						$phoneNumber = $salesordersDetail['phone'];
					}

					$data[] = array('order_type'=>'sales',
						'order_id'=>$salesordersDetail['id'],
						'customername'=>$salesordersDetail['firstName'].' '.$salesordersDetail['lastName'],
						'reference'=>$salesordersDetail['reference'],
						'email'=>$salesordersDetail['email'],
						'createdBy'=>$createdUser,
						'mobile' =>$phoneNumber,
						'createdDate'=>$salesordersDetail['createdDate'],
						'total'=>$salesordersDetail['total'],
						'deliveryAddress'=>$salesordersDetail['deliveryAddress1'].','.$salesordersDetail['deliveryAddress2'].','.$salesordersDetail['deliveryCity'].','.$salesordersDetail['deliveryState'].','.$salesordersDetail['deliveryPostalCode'].','.$salesordersDetail['deliveryCountry'],
						'billingAddress' =>$salesordersDetail['billingAddress1'].','.$salesordersDetail['billingAddress2'].','.$salesordersDetail['billingCity'].','.$salesordersDetail['billingPostalCode'].','.$salesordersDetail['billingState'].','.$salesordersDetail['billingCountry'],
						'status' =>$salesordersDetail['status'],
						'stage'=>$salesordersDetail['stage'],
						'company'=>$salesordersDetail['company'],
						'estimatedDeliveryDate'=>$salesordersDetail['estimatedDeliveryDate'],
						'trackingCode'=>$salesordersDetail['trackingCode'],
						'projectname'=>$salesordersDetail['projectName'],
						'deliveryInstructions'=>$salesordersDetail['deliveryInstructions'],
						'productDetails'=>$productDetails,
						'deliverydocketsimg'=>$img
					);	
					$result = $this->resultJsonFactory->create();

					$result->setData(['orderDetails' => $data]);
					
					//exit();
					return $result;
				}else{
					$result = $this->resultJsonFactory->create();
					$result->setData(['page' => 'no']);
					return $result;
				}

			}
			
		}
		//echo "test";
	}
}
