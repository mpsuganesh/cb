<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Customerattendancehistroy extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $customerattendance;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Customerattendance\Collection $customerattendance,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		$this->customerattendance = $customerattendance;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		
		$login_id = $this->request->getParam('login_id');
		$fromdate = $this->request->getParam('fromdate');
		$todate = $this->request->getParam('todate');
		$pageLimit = 50;
		$page = $this->request->getParam('page');
		$finalpage = ($page-1)*$pageLimit;
		$attendanceTime=$data=array();
		$result = $this->resultJsonFactory->create();
		if(!empty($login_id)&&empty($fromdate)&&empty($todate)){
			$currentMonth = date('Y-m-01');
			$currentMonthAttendance = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Customerattendance')->getCollection()->addFieldToFilter('customer_id',array('eq'=>$login_id))->addFieldToFilter('checkin_date',array('gteq'=>$currentMonth))->addFieldToFilter('status',array('eq'=>'checkout'))->setOrder('id','DESC')->load();
			$currentMonthAttendance->getSelect()->limit($pageLimit,$finalpage);
			//echo $currentMonthAttendance->getSelect();
		
			$ckattendanceData  = $currentMonthAttendance->getData();
			if(!empty($ckattendanceData)){
				$minutes = 0;
				foreach ($currentMonthAttendance as $attendanceData) {
					$checkinDate  = $attendanceData->getCheckinDate();
					$checkinTime  = $attendanceData->getCheckinTime();
					$checkoutDate = $attendanceData->getCheckoutDate();
					$checkoutTime = $attendanceData->getCheckoutTime();
					$logintime = strtotime($checkinDate.' '.$checkinTime);
					$logouttime = strtotime($checkoutDate.' '.$checkoutTime);
					$diff = $logouttime - $logintime;
					$minuts = date('i',$diff);
					$minutsArray[] = $minuts;
					$timedifference = round(abs($logouttime - $logintime)/3600);
					if($timedifference>1){
						$totalTime = $timedifference.' : '.$minuts;
						list($hour, $minute) = explode(':', $totalTime);
						$minutes += $hour * 60;
						$minutes += $minute;
					}else{
						$timedifference = 0;
						$totalTime = $timedifference.' : '.$minuts;
						list($hour, $minute) = explode(':', $totalTime);
						$minutes += $hour * 60;
						$minutes += $minute;
					}
					$attendanceTime[] =$totalTime; 
					$data[] = array('month'=>date('F'),'date'=>date('d',$logintime),'day'=>date('l',$logintime),
						'totalhours'=>$totalTime.' Hr',
					);
					
				}
				$dataCount = count($data);
				if($dataCount>50){
					$pageStatus ="yes";
				}else{
					$pageStatus = "no";
				}

				$hours = floor($minutes / 60);
				$minutes -= $hours * 60;
				$totalhours = $hours.' : '.$minutes;

				$result->setData(['selectedmonth'=>date('F'),'selectedyear'=>date('Y'),'tomonth'=>'','totalhrs'=>$totalhours,'attendancehistroy' => $data,'page'=>$pageStatus,'datCount'=>$dataCount]);
			}else{
				$result->setData(['status'=>'there is no date found','page'=>'no']);
			}
		}else{
			//echo $fromdate;
			if(!empty($login_id)&&!empty($fromdate)&&empty($todate)){
				$checkCustomerAttendance = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Customerattendance')->getCollection()->addFieldToFilter('customer_id',array('eq'=>$login_id))->addFieldToFilter('status',array('eq'=>'checkout'))->addFieldToFilter('checkin_date',array('gteq'=>$fromdate))->setOrder('id','DESC')->load();
				$checkCustomerAttendance->getSelect()->limit($pageLimit,$finalpage);
				$ckattendanceData = $checkCustomerAttendance->getData();
				if(!empty($ckattendanceData)){
					$minutes = 0;
					foreach ($checkCustomerAttendance as $attendanceData) {
						$checkinDate  = $attendanceData->getCheckinDate();
						$checkinTime  = $attendanceData->getCheckinTime();
						$checkoutDate = $attendanceData->getCheckoutDate();
						$checkoutTime = $attendanceData->getCheckoutTime();
						$logintime = strtotime($checkinDate.' '.$checkinTime);
						$logouttime = strtotime($checkoutDate.' '.$checkoutTime);
						$timedifference = abs($logouttime - $logintime)/3600;
						$diff = $logouttime - $logintime;
						$minuts = date('i',$diff);
						$minutsArray[] = $minuts;
						$timedifference = round(abs($logouttime - $logintime)/3600);
						if($timedifference>1){
						$totalTime = $timedifference.' : '.$minuts;
						list($hour, $minute) = explode(':', $totalTime);
						$minutes += $hour * 60;
						$minutes += $minute;
						}else{
						$timedifference = 0;
						$totalTime = $timedifference.' : '.$minuts;
						list($hour, $minute) = explode(':', $totalTime);
						$minutes += $hour * 60;
						$minutes += $minute;
						}
						$attendanceTime[] =$totalTime; 
						$data[] = array('month'=>date('F'),'date'=>date('d',$logintime),'day'=>date('l',$logintime),
						'totalhours'=>$totalTime.' Hr',
						);
					}
					//$totalhours = round(array_sum($attendanceTime));
					$dataCount = count($data);
					if($dataCount>50){
					$pageStatus ="yes";
					}else{
					$pageStatus = "no";
					}
					$hours = floor($minutes / 60);
					$minutes -= $hours * 60;
					$totalhours = $hours.' : '.$minutes;
					$result->setData(['selectedmonth'=>date('F',strtotime($fromdate)),'selectedyear'=>date('Y',strtotime($fromdate)),'tomonth'=>'','totalhrs'=>$totalhours,'attendancehistroy' => $data,'page'=>$pageStatus]);
				}else{
					
					$result->setData(['status'=>'there is no date found','page'=>'no']);
				}
			}else{
				if(!empty($login_id)&&!empty($fromdate)&&!empty($todate)&&(strtotime($fromdate)<=strtotime($todate))){
					$checkCustomerAttendance = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Customerattendance')->getCollection()->addFieldToFilter('customer_id',array('eq'=>$login_id))->addFieldToFilter('status',array('eq'=>'checkout'))->addFieldToFilter('checkin_date',array('gteq'=>$fromdate))->addFieldToFilter('checkin_date',array('lteq'=>$todate))->setOrder('id','DESC')->load();
					$checkCustomerAttendance->getSelect()->limit($pageLimit,$finalpage);
					$ckattendanceData = $checkCustomerAttendance->getData();
					if(!empty($ckattendanceData)){
						$minutes = 0;
						foreach ($checkCustomerAttendance as $attendanceData) {
							$checkinDate  = $attendanceData->getCheckinDate();
							$checkinTime  = $attendanceData->getCheckinTime();
							$checkoutDate = $attendanceData->getCheckoutDate();
							$checkoutTime = $attendanceData->getCheckoutTime();
							$logintime = strtotime($checkinDate.' '.$checkinTime);
							$logouttime = strtotime($checkoutDate.' '.$checkoutTime);
							$timedifference = abs($logouttime - $logintime)/3600;
							
						$diff = $logouttime - $logintime;
						$minuts = date('i',$diff);
						$minutsArray[] = $minuts;
						$timedifference = round(abs($logouttime - $logintime)/3600);
						if($timedifference>1){
						$totalTime = $timedifference.' : '.$minuts;
						list($hour, $minute) = explode(':', $totalTime);
						$minutes += $hour * 60;
						$minutes += $minute;
						}else{
						$timedifference = 0;
						$totalTime = $timedifference.' : '.$minuts;
						list($hour, $minute) = explode(':', $totalTime);
						$minutes += $hour * 60;
						$minutes += $minute;
						}
						$attendanceTime[] =$totalTime; 
						$data[] = array('month'=>date('F',$logouttime),'date'=>date('d',$logintime),'day'=>date('l',$logintime),
						'totalhours'=>$totalTime.' Hr',
						);
						}
						//$totalhours = round(array_sum($attendanceTime));
						$dataCount = count($data);
						if($dataCount>50){
						$pageStatus ="yes";
						}else{
						$pageStatus = "no";
						}
						$hours = floor($minutes / 60);
						$minutes -= $hours * 60;
						$totalhours = $hours.' : '.$minutes;
						$result = $this->resultJsonFactory->create();
						$result->setData(['selectedmonth'=>date('F',strtotime($fromdate)),'tomonth'=>date('F',strtotime($todate)),'selectedyear'=>date('Y',strtotime($fromdate)),'totalhrs'=>$totalhours,'attendancehistroy' => $data,'page'=>$pageStatus]);	
					}else{
						$result->setData(['status'=>'there is no date found','page'=>'no']);
					}
					
				}else{
					$result->setData(['status'=>'there is no date found','page'=>'no']);
				}
			}

		}
		//exit();
		return $result;
	}
}