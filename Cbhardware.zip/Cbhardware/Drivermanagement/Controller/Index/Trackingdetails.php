<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Trackingdetails extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivertracking;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivertrackingFactory $_drivertracking)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivertracking = $_drivertracking;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$driverTrackingDetails = $this->_drivertracking->create()->getCollection();
		$result = $this->resultJsonFactory->create();
		$data = array();
		foreach ($driverTrackingDetails as $trackingData) {
			$data[] = array('driver_id'=>$trackingData->getDriverId(),
				'drivername'=>$trackingData->getDriverName(),
				'latitude'=>$trackingData->getLatitude(),
				'longtitude'=>$trackingData->getLongtitude()
			);
		}
		$result->setData(['trackingdata'=>$data]);
		return $result;
	}
}
