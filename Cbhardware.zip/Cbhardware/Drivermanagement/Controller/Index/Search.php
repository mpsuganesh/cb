<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Search extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Magento\Framework\App\Request\Http $request)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->request = $request;
		return parent::__construct($context);
	}

	public function execute()
	{
		$search = $this->getRequest()->getParam('search');
		$searchType = $this->getRequest()->getParam('searchtype');
		//$page = $this->getRequest()->getParam('page');
		$result = $this->resultJsonFactory->create();
		if(!empty($search)&&!empty($searchType)&&$searchType=='sales'){
			$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='New' AND status='APPROVED'");
			//echo $searchData;
			//exit();
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/SalesOrders/?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				//echo $response;
				$salesorders = json_decode($response,true);
				$salesordersData = [];
				if(!empty($salesorders)){
					foreach ($salesorders as $sales) {
						$salesordersData['status'] ="success";
						$salesordersData['code'] ="200";
						$data[] = array('order_id'=>$sales['id'],
							'createdDate'=>$sales['createdDate'],
							'reference'=>$sales['reference'],
							'total'=>$sales['total'],
							'status' =>$sales['status'],
							'stage'=>$sales['stage'],
							'company'=>$sales['company'],
							'estimatedDeliveryDate'=>$sales['estimatedDeliveryDate'],
							'projectname'=>$sales['projectName'],
							'trackingCode'=>$sales['trackingCode'],
							'email'=>$sales['email']
						);
			//$salesordersData[]= $data;
						$result = $this->resultJsonFactory->create();
						$result->setData(['Details' => $data,
							'page'=>'yes','status'=>'success']);
					}
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}
		}

		// seach sales order histroy
		if(!empty($search)&&!empty($searchType)&&$searchType=='dispatched'){
			$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='Dispatched'");
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/SalesOrders/?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				$salesorders = json_decode($response,true);
				$salesordersData = [];
				if(!empty($salesorders)){
					foreach ($salesorders as $sales) {
						$salesordersData['status'] ="success";
						$salesordersData['code'] ="200";
						$data[] = array('order_id'=>$sales['id'],
							'createdDate'=>$sales['createdDate'],
							'reference'=>$sales['reference'],
							'total'=>$sales['total'],
							'status' =>$sales['status'],
							'stage'=>$sales['stage'],
							'company'=>$sales['company'],
							'estimatedDeliveryDate'=>$sales['estimatedDeliveryDate'],
							'projectname'=>$sales['projectName'],
							'trackingCode'=>$sales['trackingCode'],
							'email'=>$sales['email']
						);
						$result = $this->resultJsonFactory->create();
						$result->setData(['Details' => $data,
							'page'=>'yes','status'=>'success']);
					}
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}

		}
		// end search sales order histroy
		
		// search purchase orders
		if(!empty($search)&&!empty($searchType)&&$searchType=='purchase'){
			$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='New' AND status='APPROVED'");
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/PurchaseOrders?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				$purchaseorders = json_decode($response,true);
				$purchaseordersData = [];
				if(!empty($purchaseorders)){
					foreach ($purchaseorders as $purchaseorder) {
						$purchaseordersData['status'] ="success";
						$purchaseordersData['code'] ="200";
						$data[] = array('order_id'=>$purchaseorder['id'],
							'createdDate'=>$purchaseorder['createdDate'],
							'reference'=>$purchaseorder['reference'],
							'total'=>$purchaseorder['total'],
							'status' =>$purchaseorder['status'],
							'stage'=>$purchaseorder['stage'],
							'company'=>$purchaseorder['company'],
							'estimatedDeliveryDate'=>$purchaseorder['estimatedDeliveryDate'],
							'projectname'=>$purchaseorder['projectName'],
							'trackingCode'=>$purchaseorder['trackingCode'],
							'email'=>$purchaseorder['email']
						);
						$result = $this->resultJsonFactory->create();
						$result->setData(['Details' => $data,
							'page'=>'yes','status'=>'success']);
					}
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}

		}
		// end search purchase orders

		// search purchase order histroy
		if(!empty($search)&&!empty($searchType)&&$searchType=='recived'){
			$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='Received' OR stage='Completed' AND status='APPROVED'");
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/PurchaseOrders?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				$purchaseorders = json_decode($response,true);
				$purchaseordersData = [];
				if(!empty($purchaseorders)){
					foreach ($purchaseorders as $purchaseorder) {
						$purchaseordersData['status'] ="success";
						$purchaseordersData['code'] ="200";
						$data[] = array('order_id'=>$purchaseorder['id'],
							'createdDate'=>$purchaseorder['createdDate'],
							'reference'=>$purchaseorder['reference'],
							'total'=>$purchaseorder['total'],
							'status' =>$purchaseorder['status'],
							'stage'=>$purchaseorder['stage'],
							'company'=>$purchaseorder['company'],
							'estimatedDeliveryDate'=>$purchaseorder['estimatedDeliveryDate'],
							'projectname'=>$purchaseorder['projectName'],
							'trackingCode'=>$purchaseorder['trackingCode'],
							'email'=>$purchaseorder['email']
						);
						$result = $this->resultJsonFactory->create();
						$result->setData(['Details' => $data,
							'page'=>'yes','status'=>'success']);
					}
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}

		}
		// end purchase order histroy
		//search picking orders 
		 if(!empty($search)&&!empty($searchType)&&$searchType=='picking'){

		 	$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='Release To Pick' AND status='APPROVED'");
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/SalesOrders/?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				//echo $response;
				$salesorders = json_decode($response,true);
				//echo "https://api.cin7.com/api/v1/SalesOrders/?where=$searchData&order=CreatedDate%20DESC&rows=50";
			
				$salesordersData = [];
				if(!empty($salesorders)){
					foreach ($salesorders as $sales) {
						$pickingmodel = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations');
						$collection = $pickingmodel->getCollection()->addFieldToFilter('stage', 'confirmed')->addFieldToFilter('orderid', $sales['id']);
						$pickingorders =  $collection->getData();
						if(!empty($pickingorders)){
						foreach ($pickingorders as $pickingordersDetails) {
							if($pickingordersDetails['orderid']==$sales['id']){
								$salesordersData['status'] ="success";
								$salesordersData['code'] ="200";
								$data[] = array('order_id'=>$sales['id'],
								'createdDate'=>$sales['createdDate'],
								'reference'=>$sales['reference'],
								'total'=>$sales['total'],
								'status' =>$sales['status'],
								'stage'=>$sales['stage'],
								'company'=>$sales['company'],
								'estimatedDeliveryDate'=>$sales['estimatedDeliveryDate'],
								'projectname'=>$sales['projectName'],
								'trackingCode'=>$sales['trackingCode'],
								'email'=>$sales['email']
								);
								//$salesordersData[]= $data;
								$result = $this->resultJsonFactory->create();
								$result->setData(['Details' => $data,'page'=>'yes','status'=>'success']);
							}
						}	
						}

					}
					//exit();
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}
		 	//echo "test";
		 	//exit();
		 }
		// end picking orders
		// start picking order histroy
		 if(!empty($search)&&!empty($searchType)&&$searchType=='pickinghistroy'){
		 	$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='Release To Pick' AND status='APPROVED'");
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/SalesOrders/?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				//echo $response;
				$salesorders = json_decode($response,true);
				//print_r($salesorders);
				//exit();
				$salesordersData = [];
				if(!empty($salesorders)){
					foreach ($salesorders as $sales) {
						$pickingmodel = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations');
						$collection = $pickingmodel->getCollection()->addFieldToFilter('stage', 'assigned')->addFieldToFilter('orderid', $sales['id']);
						$pickingorders =  $collection->getData();
						if(!empty($pickingorders)){
						foreach ($pickingorders as $pickingordersDetails) {
							if($pickingordersDetails['orderid']==$sales['id']){
								$salesordersData['status'] ="success";
								$salesordersData['code'] ="200";
								$data[] = array('order_id'=>$sales['id'],
								'createdDate'=>$sales['createdDate'],
								'reference'=>$sales['reference'],
								'total'=>$sales['total'],
								'status' =>$sales['status'],
								'stage'=>$sales['stage'],
								'company'=>$sales['company'],
								'estimatedDeliveryDate'=>$sales['estimatedDeliveryDate'],
								'projectname'=>$sales['projectName'],
								'trackingCode'=>$sales['trackingCode'],
								'email'=>$sales['email']
								);
								//$salesordersData[]= $data;
								$result = $this->resultJsonFactory->create();
								$result->setData(['Details' => $data,
								'page'=>'yes','status'=>'success']);
							}
						}	
						}

					}
					//exit();
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}
		 	//echo "test";
		 	//exit();
		 }
		// end picking order histroy 
		// search dirver orders 
		 if(!empty($search)&&!empty($searchType)&&$searchType=='driverorders'){
		 	$driver_id = $this->getRequest()->getParam('driver_id');
		 	$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='Release To Pick' AND status='APPROVED'");
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/SalesOrders/?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				//echo $response;
				$salesorders = json_decode($response,true);
				//print_r($salesorders);
				//exit();
				$salesordersData = [];
				if(!empty($salesorders)){
					foreach ($salesorders as $sales) {
						$pickingmodel = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations');
						$collection = $pickingmodel->getCollection()->addFieldToFilter('stage', 'assigned')->addFieldToFilter('orderid', $sales['id'])->addFieldToFilter('driver_name', $driver_id);
						$pickingorders =  $collection->getData();
						if(!empty($pickingorders)){
						foreach ($pickingorders as $pickingordersDetails) {
							if($pickingordersDetails['orderid']==$sales['id']){
								$salesordersData['status'] ="success";
								$salesordersData['code'] ="200";
								$data[] = array('order_id'=>$sales['id'],
								'createdDate'=>$sales['createdDate'],
								'reference'=>$sales['reference'],
								'total'=>$sales['total'],
								'status' =>$sales['status'],
								'stage'=>$sales['stage'],
								'company'=>$sales['company'],
								'estimatedDeliveryDate'=>$sales['estimatedDeliveryDate'],
								'projectname'=>$sales['projectName'],
								'trackingCode'=>$sales['trackingCode'],
								'email'=>$sales['email']
								);
								//$salesordersData[]= $data;
								$result = $this->resultJsonFactory->create();
								$result->setData(['Details' => $data,
								'page'=>'yes','status'=>'success']);
							}
						}	
						}

					}
					//exit();
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}
		 	//echo "vvv";
		// exit();
		 }
		// end search driver orders
		 
		// search dirver orderhistroy 
		 if(!empty($search)&&!empty($searchType)&&$searchType=='driverorderhistroy'){
		 	$driver_id = $this->getRequest()->getParam('driver_id');
		 	$searchData = rawurlencode("(firstName like '".$search."%' or lastName like '".$search."%' or reference like '".$search."%' or company like '".$search."%' or projectName like '".$search."%') AND stage='Dispatched'");
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL =>"https://api.cin7.com/api/v1/SalesOrders/?where=$searchData&order=CreatedDate%20DESC&rows=50",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				$result->setData(['page' => 'no','status'=>'error','message'=>$err]);
			} else {
				//echo $response;
				$salesorders = json_decode($response,true);
				//print_r($salesorders);
				//exit();
				$salesordersData = [];
				if(!empty($salesorders)){
					foreach ($salesorders as $sales) {
						$drivermodel = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Deliverydockets');
						$collection = $drivermodel->getCollection()->addFieldToFilter('stage', 'Dispatched')->addFieldToFilter('order_id', $sales['id'])->addFieldToFilter('driver_id', $driver_id);
						$driverOrders =  $collection->getData();

						//echo $collection->getSelect();

						if(!empty($driverOrders)){
						foreach ($driverOrders as $driverOrderDetails) {
							if($driverOrderDetails['order_id']==$sales['id']){
								$salesordersData['status'] ="success";
								$salesordersData['code'] ="200";
								$data[] = array('order_id'=>$sales['id'],
								'createdDate'=>$sales['createdDate'],
								'reference'=>$sales['reference'],
								'total'=>$sales['total'],
								'status' =>$sales['status'],
								'stage'=>$sales['stage'],
								'company'=>$sales['company'],
								'estimatedDeliveryDate'=>$sales['estimatedDeliveryDate'],
								'projectname'=>$sales['projectName'],
								'trackingCode'=>$sales['trackingCode'],
								'email'=>$sales['email']
								);
								//$salesordersData[]= $data;
								//print_r($data);
								$result = $this->resultJsonFactory->create();
								$result->setData(['Details' => $data,'page'=>'yes','status'=>'success']);
							}
						}	
						}

					}
					//exit();
				}else{
					$result->setData(['page' => 'no','status'=>'error','message'=>'there is no data found']);
					
				}
			}
		 	//echo "vvv";
		// exit();
		 }
		// end search driver orderhistroy



		return $result;
	}
}