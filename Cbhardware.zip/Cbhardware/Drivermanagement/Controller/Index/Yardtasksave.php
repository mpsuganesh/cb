<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Yardtasksave extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_yardtask;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Cbhardware\Drivermanagement\Model\YardtaskFactory $_yardtask)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_yardtask = $_yardtask;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		//echo "test";
		$result = $this->resultJsonFactory->create();
		$task = $this->getRequest()->getParam('yardtsk');
		$driverid = $this->getRequest()->getParam('deriver_id');
		$yardtaskMarkedid = $this->getRequest()->getParam('mark_id');
		$markedDriver = $this->getRequest()->getParam('marked_driver');
		if(!empty($task)&&!empty($driverid)&&empty($yardtaskMarkedid)){
		$date = date('Y-m-d');
		//echo $date;
		//exit();
		$yardtask = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Yardtask');
		$yardtask->setDriverId($driverid);
		$yardtask->setYardtask($task);
		$yardtask->setStatus('1');
		$yardtask->setDate($date);
		$yardtask->save();
		$yardtasklist = $this->_yardtask->create()->getCollection()->addFieldToFilter('driver_id', $driverid)->addFieldToFilter('date',$date);
		$datacheck  =$yardtasklist->getData();
		if(!empty($datacheck)){
			foreach ($yardtasklist as  $tasklist){
			$taskdriverid = $tasklist->getDriverId();
			$id = $tasklist->getId();
			$marked = $tasklist->getMarkedStatus();
			//echo $driverid;
			$task = $tasklist->getYardtask();
			$data[] =array('id'=>$id,'driver_id'=>$taskdriverid,'task'=>$task,'markedstatus'=>$marked);
			# code...
		}
		}

		$result->setData(['status'=>'success','message'=>'Success fully saved..','yardtasklist'=>$data]);
		}else{
			if(!empty($yardtaskMarkedid)){
				$yardtasklist = $this->_yardtask->create()->getCollection()->addFieldToFilter('id', $yardtaskMarkedid);
				//print_r($yardtasklist->getData());
				foreach ($yardtasklist as $yardTask){
					//print_r($yardTask);
					$yardTask->setMarkedStatus("marked");
					$yardTask->setName($markedDriver);
				}
				//echo $markedDriver;
				//exit();
				$yardtasklist->save();
				$yardtasklistDetails = $this->_yardtask->create()->getCollection();
				$datacheck  =$yardtasklistDetails->getData();
				foreach ($yardtasklistDetails as  $tasklist){
				$taskdriverid = $tasklist->getDriverId();
				$id = $tasklist->getId();
				$marked = $tasklist->getMarkedStatus();
				//echo $driverid;
				$task = $tasklist->getYardtask();
				$data[] =array('id'=>$id,'driver_id'=>$taskdriverid,'task'=>$task,'markedstatus'=>$marked);
				# code...
				}

				$result->setData(['status'=>'success','message'=>'Success fully marked..','yardtasklist'=>$data]);

			}else{
				$result->setData(['status'=>'error','message'=>'not save']);
			}
			//echo "test";
			//exit();
			
		}
		return $result;	
		

	}
}
