<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Driverorderdetail extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $salesorderconfirmations;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Salesorderconfirmations\Collection $salesorderconfirmations,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->salesorderconfirmations = $salesorderconfirmations;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$orderid = $this->request->getParam('orderid');
		$login_id = $this->request->getParam('login_id');
		$driverorders = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Salesorderconfirmations');
		$collection = $driverorders->getCollection()->addFieldToFilter('orderid', $orderid)->addFieldToFilter('driver_name',$login_id);
		$driverorder =  $collection->getData();

		if(!empty($orderid)&&!empty($driverorder)){
			$curl = curl_init();

			curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/SalesOrders/$orderid",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
				echo "cURL Error #:" . $err;
			}else{
				$salesordersDetail = json_decode($response,true);
				$salesordersData = [];
				if(!empty($salesordersDetail)){
					
					// get create by 
					$createdBy = $salesordersDetail['createdBy'];
					$curl = curl_init();
					curl_setopt_array($curl, array(
						CURLOPT_URL => "https://api.cin7.com/api/v1/Users/$createdBy",
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => "",
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 30,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => "GET",
						CURLOPT_HTTPHEADER => array(
							"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"),
					));

					$createdBy = curl_exec($curl);
					$err = curl_error($curl);

					curl_close($curl);

					if ($err) {
						echo "cURL Error #:" . $err;
					} else {
						$userDetails = json_decode($createdBy,true);
						if(!empty($userDetails)){
							$createdUser = $userDetails['firstName'].' '.$userDetails['lastName'];
						}else{
							$createdUser = '';
						}
					}
					// end of created by


					// get product details
						//print_r($salesordersDetail['lineItems']);
					if(!empty($salesordersDetail['lineItems'])){

					foreach ($salesordersDetail['lineItems'] as $lineItems) {
						$productId = $lineItems['productId'];
						$curl = curl_init();
						curl_setopt_array($curl, array(
							CURLOPT_URL => "https://api.cin7.com/api/v1/Products/$productId",
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_ENCODING => "",
							CURLOPT_MAXREDIRS => 10,
							CURLOPT_TIMEOUT => 30,
							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							CURLOPT_CUSTOMREQUEST => "GET",
							CURLOPT_HTTPHEADER => array(
								"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"),
						));

						$productimg = curl_exec($curl);
						$productimages = json_decode($productimg,true);
						$productimagesck = $productimages['images'];
						if(count($productimagesck)>0){
							//$proimg = $productimages['images'][0]['link'];
							if(!empty($productimages['productOptions'][0]['image'])){
								$proimg = $productimages['productOptions'][0]['image']['link'];
							}else{

							$proimg = $productimages['images'][0]['link'];
							}
						}else{
							$proimg = '';
						}
						$err = curl_error($curl);

						curl_close($curl);
						$productDetails[] = array('name'=>$lineItems['name'],
							'code'=>$lineItems['code'],
							'qty'=>$lineItems['qty'],
							'uinitprice'=>$lineItems['unitPrice'],
							'discount'=>$lineItems['discount'],
							'productTotalprice'=>($lineItems['qty']*$lineItems['unitPrice'])-($lineItems['discount']),
							'productimage'=>$proimg,
						);
							# code...
					}
					}else{
						$productDetails=array();
					}
					if(!empty($salesordersDetail['mobile'])){
							$phoneNumber = $salesordersDetail['mobile'];
							}else{
							$phoneNumber = $salesordersDetail['phone'];
							}
					// end get product details

					$data[] = array('order_type'=>'sales',
						'order_id'=>$salesordersDetail['id'],
						'customername'=>$salesordersDetail['firstName'].' '.$salesordersDetail['lastName'],
						'reference'=>$salesordersDetail['reference'],
						'email'=>$salesordersDetail['email'],
						'createdBy'=>$createdUser,
						'mobile' =>$phoneNumber,
						'createdDate'=>$salesordersDetail['createdDate'],
						'total'=>$salesordersDetail['total'],
						'deliveryAddress'=>$salesordersDetail['deliveryAddress1'].','.$salesordersDetail['deliveryAddress2'].','.$salesordersDetail['deliveryCity'].','.$salesordersDetail['deliveryState'].','.$salesordersDetail['deliveryPostalCode'].','.$salesordersDetail['deliveryCountry'],
						'billingAddress' =>$salesordersDetail['billingAddress1'].','.$salesordersDetail['billingAddress2'].','.$salesordersDetail['billingCity'].','.$salesordersDetail['billingPostalCode'].','.$salesordersDetail['billingState'].','.$salesordersDetail['billingCountry'],
						'status' =>$salesordersDetail['status'],
						'stage'=>$salesordersDetail['stage'],
						'company'=>$salesordersDetail['company'],
						'estimatedDeliveryDate'=>$salesordersDetail['estimatedDeliveryDate'],
						'projectname'=>$salesordersDetail['projectName'],
						'trackingCode'=>$salesordersDetail['trackingCode'],
						'productDetails'=>$productDetails,
					);	
					$result = $this->resultJsonFactory->create();

					$result->setData(['orderDetails' => $data]);
					
					//exit();
					return $result;
				}else{
					$result = $this->resultJsonFactory->create();
					$result->setData(['orderDetails' => 'no data found']);
					//return $result;
				}

			}
			
		}else{
			$result = $this->resultJsonFactory->create();
			$result->setData(['orderDetails' => 'no data found']);
		}
		return $result;
		
	}
}