<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_storeManager;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->_storeManager = $storeManager;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$username = $this->request->getParam('username');
		$password = $this->request->getParam('password');
		$deviceToken = $this->request->getParam('device_token');
		$driveraccountdetails = $this->_mobileapi->create()->getCollection()
		->addFieldToFilter('username',array('eq'=>$username))
		->addFieldToFilter('password',array('eq'=>$password));
		$k2bDriverData = [];
		$path = $this->_storeManager->getStore()->getBaseUrl().$this->_storeManager->getStore()->getBaseMediaDir()."/myprofile/";
		foreach ($driveraccountdetails as $finaldata){
			if(!empty($deviceToken)){
				//echo $deviceToken;
				$finaldata->setDeviceToken($deviceToken);
			}else{
				$deviceToken = "";
				$finaldata->setDeviceToken($deviceToken);
			}
			//print_r($finaldata);
			//exit();
			if($finaldata->getDriverDetails() == 0){

				$k2bDriverData['status'] ="success";
				$k2bDriverData['code'] ="200";
				$data = array("id"=>$finaldata->getId(),
					"account"=>"Owner",
					"name"=>$finaldata->getName(),
					"email"=>$finaldata->getEmail(),
					"street_address"=>$finaldata->getStreetAddress(),
					"street_address_line_2"=>$finaldata->getStreetAddressLine2(),
					"city"=>$finaldata->getCity(),
					"country"=>$finaldata->getCountryId(),
					"state"=>$finaldata->getState(),
					"postalcode"=>$finaldata->getPostalCode(),
					"mobileno"=>$finaldata->getMobileNo(),
					"maritalStatus"=>$finaldata->getMaritalStatus(),
					"accountid"=>$finaldata->getDriverDetails(),
					"sales"=>$finaldata->getSales(),
					"picking"=>$finaldata->getPicking(),
					"purchase"=>$finaldata->getPurchase(),
					"vehicle"=>$finaldata->getVehicle(),
					"active"=>$finaldata->getActive(),
					"dob"=>$finaldata->getDob(),
					"profileimg"=>$path.$finaldata->getProfileImg()
				);
				$k2bDriverData['accountdetails']= $data;

			}
			else{
				$k2bDriverData['status'] ="success";
				$k2bDriverData['code'] ="200";
				$data = array("id"=>$finaldata->getId(),
					"account"=>"Driver",
					"name"=>$finaldata->getName(),
					"email"=>$finaldata->getEmail(),
					"street_address"=>$finaldata->getStreetAddress(),
					"street_address_line_2"=>$finaldata->getStreetAddressLine2(),
					"city"=>$finaldata->getCity(),
					"country"=>$finaldata->getCountryId(),
					"state"=>$finaldata->getState(),
					"postalcode"=>$finaldata->getPostalCode(),
					"mobileno"=>$finaldata->getMobileNo(),
					"maritalStatus"=>$finaldata->getMaritalStatus(),
					"accountid"=>$finaldata->getDriverDetails(),
					"sales"=>$finaldata->getSales(),
					"picking"=>$finaldata->getPicking(),
					"purchase"=>$finaldata->getPurchase(),
					"vehicle"=>$finaldata->getVehicle(),
					"active"=>$finaldata->getActive(),
					"dob"=>$finaldata->getDob(),
					"profileimg"=>$path.$finaldata->getProfileImg()
				);

				$k2bDriverData['accountdetails']= $data;
				$driverData = $this->_drivermanagement->create()->getCollection()->addFieldToFilter('id',array('eq'=>$data['accountid']));
				foreach ($driverData as $finaldata){
					$licence = $finaldata->getLicenceNumber();
						$data = array("id"=>$finaldata->getId(),
						"drivername"=>$finaldata->getDriverName(),
						"email"=>$finaldata->getEmail(),
						"dob"=>$finaldata->getDob(),
						"licencenumber "=>$finaldata->getLicenceNumber(),
						"locations"=>$finaldata->getLocations()
					);
					$k2bDriverData['driverdetails']= $data;

				}
				
			}
			
			
			
		}
		
		
		$result = $this->resultJsonFactory->create();

		
		if(count($k2bDriverData)>0){
			$result->setData(['Details' => $k2bDriverData]);
			$driveraccountdetails->save();
			return $result;  
		}
		else{
			$k2bDriverData1 = [];
			$k2bDriverData1['status'] ="failed";
			$k2bDriverData1['message'] ="Invalid login";
			$k2bDriverData1['code'] ="400";
			$result2 = $this->resultJsonFactory->create();
			$result2->setData(['Details' => $k2bDriverData1]);
			return $result2;  
			
		}
				//$newsModel = $this->_TestimonialFactory->create();
		//$newsCollection = $newsModel->getCollection();
        // Load all data of collection
        //echo json_encode($diriverdetails);
		//exit();
		//return json_encode($diriverdetails);
	}
}
