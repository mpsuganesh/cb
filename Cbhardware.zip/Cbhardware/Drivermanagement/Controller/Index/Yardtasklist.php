<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Yardtasklist extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_yardtask;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Cbhardware\Drivermanagement\Model\YardtaskFactory $_yardtask)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_yardtask = $_yardtask;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$pageLimit = 50;
		$driver_id = $this->getRequest()->getParam('driver_id');
		$page = $this->getRequest()->getParam('page');
		$date = $this->getRequest()->getParam('date');
		$finalpage = ($page-1)*$pageLimit;
		$result = $this->resultJsonFactory->create();
		if(!empty($page)&&empty($date)){
		$yardtask = $this->_yardtask->create()->getCollection();
		$yardtask->getSelect()->limit($pageLimit,$finalpage);
		$data = array();
		$datacheck  =$yardtask->getData();
		if(!empty($datacheck)){

		foreach ($yardtask as  $tasklist){
			$driverid = $tasklist->getDriverId();
			$id = $tasklist->getId();
			//echo $driverid;
			$yardtask = $tasklist->getYardtask();
			$markedstatus = $tasklist->getMarkedStatus();
			$name = $tasklist->getName();
			$data[] =array('id'=>$id,'driver_id'=>$driver_id,'task'=>$yardtask,'markedstatus'=>$markedstatus,'drivername'=>$name);
			# code...
		}
		$result->setData(['yardtasklist'=>$data,'status'=>'success','page'=>'yes']);
		}else{
		$result->setData(['status'=>'success','page'=>'no','message'=>'there is no data found']);	
		} 
		
		}else{
			if(!empty($page)&&!empty($date)){
			$yardtask = $this->_yardtask->create()->getCollection()->addFieldToFilter('date', $date);
			$yardtask->getSelect()->limit($pageLimit,$finalpage);
			$data = array();
			$datacheck  =$yardtask->getData();
			if(count($datacheck)>0){
			foreach ($yardtask as  $tasklist){
			$driverid = $tasklist->getDriverId();
			$id = $tasklist->getId();
			//echo $driverid;
			$yardtask = $tasklist->getYardtask();
			$markedstatus = $tasklist->getMarkedStatus();
			$name = $tasklist->getName();
			$data[] =array('id'=>$id,'driver_id'=>$driver_id,'task'=>$yardtask,'markedstatus'=>$markedstatus,'drivername'=>$name);
			# code...
			}
			$result->setData(['yardtasklist'=>$data,'status'=>'success','page'=>'yes']);
			}else{
				$result->setData(['status'=>'error','page'=>'no','message'=>'there is no data found']);
			}
			}else{
			$result->setData(['status'=>'error','page'=>'no','message'=>'there is no data found']);
			}
		}
		return $result;
		//echo "test";
		
	}
}
