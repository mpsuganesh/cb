<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Sendforgotmail extends \Magento\Framework\App\Action\Action
{
	const XML_PATH_EMAIL_RECIPIENT_NAME = 'trans_email/ident_support/name';
	const XML_PATH_EMAIL_RECIPIENT_EMAIL = 'trans_email/ident_support/email';
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $_inlineTranslation;
	protected $_transportBuilder;
	protected $_scopeConfig;
	protected $_logLoggerInterface;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
		\Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Psr\Log\LoggerInterface $loggerInterface,
		array $data = [])
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		$this->_inlineTranslation = $inlineTranslation;
		$this->_transportBuilder = $transportBuilder;
		$this->_scopeConfig = $scopeConfig;
		$this->_logLoggerInterface = $loggerInterface;
		$this->messageManager = $context->getMessageManager();
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$post = $this->getRequest()->getPost();
		$driveraccountdetails = $this->_mobileapi->create()->getCollection()->addFieldToFilter('email',array('eq'=>$post['email']));
		$accountDetails = $driveraccountdetails->getData();
		$storeManager = $this->_objectManager->get('\Magento\Store\Model\StoreManagerInterface');
		
		if(!empty($accountDetails)){
			$accountName = $accountDetails[0]['name'];
			$this->_inlineTranslation->suspend();
			$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
			$sender = [
				'name' =>$this->_scopeConfig ->getValue('trans_email/ident_general/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE),
				'email' => $this->_scopeConfig ->getValue('trans_email/ident_general/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE)
			];
			$sentToEmail = $post['email'];
			$sentToName = $accountName;
			$transport = $this->_transportBuilder
			->setTemplateIdentifier('mobileforgot_email_template')
			->setTemplateOptions(
				[
					'area' => 'frontend',
					'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
				]
			)
			->setTemplateVars([
				'name'  => $accountName,
				'email'  => $post['email'],
				'baseurl'=>$storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB)
			])
			->setFrom($sender)
			->addTo($sentToEmail,$sentToName)
			->getTransport();
			$transport->sendMessage();
			$this->_inlineTranslation->resume();
			$result = $this->resultJsonFactory->create();
			$result->setData(['status' => 'ok','message'=>'Mail has been sent']);
		}else{
			$result = $this->resultJsonFactory->create();
			$result->setData(['status' => 'error','message'=>'Your not register user']);
		}
		return $result;
	}
}
