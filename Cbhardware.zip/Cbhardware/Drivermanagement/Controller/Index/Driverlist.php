<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Driverlist extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$driveraccountdetails = $this->_mobileapi->create()->getCollection()->addFieldToFilter('driver_details',array('neq'=>0));
		$driverData =  $driveraccountdetails->getData();
		$result = $this->resultJsonFactory->create();
		if(!empty($driverData)){
		foreach($driverData as $driverDetails){
		$drivers[] = array('driverid'=>$driverDetails['id'],
		'drivername'=>$driverDetails['name']);
		}
		$result->setData(['driverlist' => $drivers]);
		}else{
			$result->setData(['status' => 'error','message'=>'There is no data found']);
		}
		return $result;
		//print_r($drivers);
		
	}
}