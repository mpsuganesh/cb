<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Fullyreceived extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $_purchaseorders;
	protected $_mediaDirectory;
	protected $_fileUploaderFactory;
	protected $request;
	protected $logger;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Cbhardware\Drivermanagement\Model\PurchaseordersFactory $_purchaseorders,
		\Psr\Log\LoggerInterface $logger,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
		\Magento\Framework\Filesystem $filesystem,
		\Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->_purchaseorders = $_purchaseorders;
		$this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
		$this->_fileUploaderFactory = $fileUploaderFactory;
		$this->_logger = $logger;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$result = $this->resultJsonFactory->create();
		$orderId = (int)$this->getRequest()->getParam('orderid');
		$purchaseorderImg = $this->getRequest()->getParam('purchseorder_img');
		
		$lineItems = json_decode($this->getRequest()->getParam('lineItems'),true);	
		
		if(!empty($orderId)&&!empty($lineItems)){
		// get Line Item //
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => "https://api.cin7.com/api/v1/PurchaseOrders/$orderId",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi"
				),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
		//echo "cURL Error #:" . $err;
				$result->setData(['status'=>'error','message'=>$err]);
			}else{
				$orderDetails = json_decode($response,true);
				$orderItem = array();
				//print_r($orderDetails['lineItems']);
				foreach ($lineItems as $key => $received) {
					$ordercheckitem[] = $received['id'];
					$ordercheckitemqty[$received['id']] = $received['qty'];

				}
				foreach ($orderDetails['lineItems'] as $existskey => $line) {
					if(in_array($line['id'], $ordercheckitem)){
						$finalLineItem[] = array('id'=>$line['id'],'qty'=>$ordercheckitemqty[$line['id']]);
					}else{
						$finalLineItem[]=array('id'=>$line['id'],'qty'=>0);
						//$notrecivedArray[]=$line['id'];
					}
					//$orderItem[] = $line['id'];
					/*foreach ($lineItems as $key => $received) {
						$key = array_search($received['id'], array_column($orderDetails['lineItems'], 'id'));
						if($key==$existskey){

						$finalLineItem[$existskey] = $received;
						}else{
							$finalLineItem[]=array('id'=>$orderDetails['lineItems'][$existskey]['id'],'qty'=>0,'qtyShipped'=>0);
						}
						//print_r($received);
						//$key = array_search(78199, array_column($orderDetails['lineItems'], 'id'));
					}*/
					//echo $existskey;
					//print_r($orderDetails['lineItems']);
						//$receivedqty[] = $finalLineItem[$existskey];
				}

				//print_r($receivedArray);
				//print_r($finalLineItem);
				// prem test
				//exit();
				
				$currentDatetime  = gmdate('c');
				$orderData[] = array('id'=>$orderId,'lineItems'=>$finalLineItem,"status"=>"APPROVED","stage"=>"Received",'fullyReceivedDate'=>$currentDatetime);
				$finalOrderdata = json_encode($orderData,true);	
				//echo $finalOrderdata;

					//print_r($finalOrderdata);
				//exit();
				
				//print_r($receivedqty);
				

				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => "https://api.cin7.com/api/v1/PurchaseOrders/?loadboms=%7Bloadboms%7D",
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => "",
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 30,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => "PUT",
					CURLOPT_POSTFIELDS => $finalOrderdata,
					CURLOPT_HTTPHEADER => array(
						"authorization: Basic Q2FtcGJlbGx0b3duQnVpMkFVOjdhNDcwOTg3Y2Q3NTQzYmE5ODZlYzdjYzA5MjcxZjFi",
						"content-type: application/json"
					),
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);
				if ($err) {
			//echo "cURL Error #:" . $err;
					$result->setData(['status'=>'error','message'=>$err]);
				} else {
					$finalresponse = json_decode($response,true);
					if($finalresponse[0]['success']==1){
						// prem save purchase order in our Magento back end
						$customername = $orderDetails['firstName'].' '.$orderDetails['lastName'];
						$path = $this->_mediaDirectory->getAbsolutePath('purchaseordersignature/');
						$signature = $this->getRequest()->getParam('signature');
						$comments = $this->getRequest()->getParam('comments');
						$reciverName = $this->getRequest()->getParam('reciver_name');
						$receivedDate = date('d-m-Y');
						$purchaseorders = $this->_purchaseorders->create();
						if(!empty($signature)){
						$imageBase = base64_decode($signature);
						$filname = uniqid() . '.png';
						$file = $path.$filname;
						file_put_contents($file, $imageBase);
						}else{
						$filname='';
						}
						if(!empty($orderDetails['phone'])){
							$contactNumber = $orderDetails['phone'];
						}else{
							$contactNumber = $orderDetails['mobile'];
						}
						// purchase order image save
						$purchaseorderimages = json_decode($purchaseorderImg,true);
						if(!empty($purchaseorderimages)){
						foreach ($purchaseorderimages as $docketimg1) {
						$imageBase = base64_decode($docketimg1);
						$filename = uniqid() . '.png';
						$file = $path.$filename;
						$fname[] = $filename;
						file_put_contents($file, $imageBase);
						}
						$finalFilename = implode("@", $fname);
						}else{
						$finalFilename='';
						}
						// end purchase order image save
						$createddate = strtotime($orderDetails['createdDate']);
						$createdDate = date('d-m-Y',$createddate);

						$purchaseorders->setCreatedDate($createdDate);
						$purchaseorders->setRecivedDate($receivedDate);
						$purchaseorders->setCustomerName($customername);
						$purchaseorders->setEmail($orderDetails['email']);
						$purchaseorders->setCompanyName($orderDetails['company']);
						$purchaseorders->setReferenceNo($orderDetails['reference']);
						$purchaseorders->setTotalAmount($orderDetails['total']);
						$purchaseorders->setContactNumber($contactNumber);
						$purchaseorders->setComments($comments);
						$purchaseorders->setSignature($filname);
						$purchaseorders->setRecivedImg($finalFilename);
						$purchaseorders->setReciverName($reciverName);
						$purchaseorders->save();
						// end save purchase order save magento back end
						$result->setData(['status'=>'success','message'=>'Success Received.']);
					}
				}
			}
		}
		return $result;
	}						


		//

}