<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Forkliftlist extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $_drivermanagement;
    protected $resultJsonFactory; 
    protected $_mobileapi;
    protected $request;
    protected $_yardtask;

    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\App\Request\Http $request
    )
    {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_pageFactory = $pageFactory;
        $this->request = $request;
        return parent::__construct($context);
        
    }

    public function execute()
    {
        $result = $this->resultJsonFactory->create();
        $modelType = $this->getRequest()->getParam('model_type');
        $forkliftform = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Forkliftform')->getCollection();
        //print_r($forkliftform->getData());
        foreach($forkliftform as $getforklift){
            $data[] = array("modelname"=>$getforklift->getModelType());
            //$forkliftForm = json_decode($getforklift->getForkliftForm(),true);
        }
        $result->setData(['modellist'=>$data]);
        return $result;
        
    }
}
