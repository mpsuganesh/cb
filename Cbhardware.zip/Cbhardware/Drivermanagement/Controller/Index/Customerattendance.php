<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Customerattendance extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobileapi;
	protected $request;
	protected $customerattendance;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi,
		\Magento\Framework\App\Request\Http $request,
		\Cbhardware\Drivermanagement\Model\ResourceModel\Customerattendance\Collection $customerattendance,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobileapi = $_mobileapi;
		$this->request = $request;
		$this->customerattendance = $customerattendance;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$login_id = $this->request->getParam('login_id');
		$checkType = $this->request->getParam('checktype');
		$login_name = $this->request->getParam('login_name');
		$customerAttendance = $this->customerattendance;
		$currentDate = date('Y-m-d');
		$currentTime = date('h:i:sa');
		//echo $currentTime;
		//exit();
		if(!empty($login_id)&&!empty($checkType)&&$checkType=='checkin'){
			$latitude = $this->request->getParam('latitude');
			$longtitude = $this->request->getParam('longtitude');
			
			//exit();
			$result = $this->resultJsonFactory->create();
			$checkCustomerAttendance = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Customerattendance')->getCollection()->addFieldToFilter('customer_id',array('eq'=>$login_id))->addFieldToFilter('status',array('eq'=>$checkType))->setOrder('customer_id','DESC')->load();
			$checkCustomerAttendance->getSelect()->limit(1);
			$existsdata = $checkCustomerAttendance->getData();
			if(!empty($existsdata)){
				foreach ($checkCustomerAttendance as $attendance) {
					$attendance->setCheckinDate($currentDate);
					$attendance->setCheckinTime($currentTime);
					$attendance->setStatus($checkType);
					$attendance->setLocations("xsss");
				}
				$checkCustomerAttendance->save();
			//echo "saved";
				$status['status'] ="success";
				$status['login_status'] = 'checkin';
				$status['message'] = 'successfully checkedin';
				$status['code'] ="200";
				$result->setData(['resultset' => $status]);
			}else{
				$attendanceEntry = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Customerattendance');
					if(!empty($latitude)&&!empty($longtitude)){
					$url = sprintf("https://maps.googleapis.com/maps/api/geocode/json?latlng=%s,%s", $latitude, $longtitude."&key=AIzaSyB-sF0MIAAAc3LWilBnoyE_AGytf9s554I");
					$content = file_get_contents($url); // get json content

					$metadata = json_decode($content, true); //json decoder


					if(count($metadata['results']) > 0) {

					$loginAddressArray = $metadata['results'][0];

					$loginAddress = $loginAddressArray['formatted_address'];

					}
					}
					//echo $loginAddress;
					//exit();
				$attendanceEntry->setCustomerId($login_id);
				$attendanceEntry->setCheckinDate($currentDate);
				$attendanceEntry->setCheckinTime($currentTime);
				$attendanceEntry->setStatus($checkType);
				$attendanceEntry->setLocations($loginAddress);
				$attendanceEntry->setCustomerName($login_name);
				$attendanceEntry->save();
				$status['status'] ="success";
				$status['login_status'] = 'checkin';
				$status['message'] = 'successfully checkedin cc';
				$status['code'] ="200";
				$result->setData(['resultset' => $status]);
				
			}

		}else{
			if(!empty($login_id)&&!empty($checkType)&&$checkType=='checkout'){
				$result = $this->resultJsonFactory->create();
				$checkCustomerAttendance = $this->_objectManager->create('Cbhardware\Drivermanagement\Model\Customerattendance')->getCollection()->addFieldToFilter('customer_id',array('eq'=>$login_id))->addFieldToFilter('status',array('eq'=>'checkin'))->setOrder('customer_id','DESC')->load();
				$checkCustomerAttendance->getSelect()->limit(1);
				$existsdata = $checkCustomerAttendance->getData();
				if(!empty($existsdata)){
					$minutes = 0;
					foreach ($checkCustomerAttendance as $attendance) {
						$checkinDate  = $attendance->getCheckinDate();
						$checkinTime  = $attendance->getCheckinTime();
						$logintime = strtotime($checkinDate.' '.$checkinTime);
						$logouttime = strtotime($currentDate.' '.$currentTime);
						$timedifference = abs($logouttime - $logintime)/3600;
						$diff = $logouttime - $logintime;
						$minuts = date('i',$diff);
						if($timedifference>1){
							$totalHours = round($timedifference);
						$totalTime = $totalHours.' : '.$minuts;
						}else{
							$timedifference =0;
							$totalTime = $timedifference.' : '.$minuts;
						}
						$attendance->setCheckoutDate($currentDate);
						$attendance->setCheckoutTime($currentTime);
						$attendance->setStatus($checkType);
						$attendance->setTotalHours($totalTime);
						
					}
					$status['status'] ="success";
					$status['login_status'] = 'checkout';
					$status['message'] = 'successfully checkout';
					$status['code'] ="200";
					$result->setData(['resultset' => $status]);
					$checkCustomerAttendance->save();
				}else{
					$status['status'] ="error";
					$status['code'] ="200";
					$result->setData(['resultset' => $status]);
				}

			}
		}
		return $result;       
		
		
        //die('test');		
	}
}