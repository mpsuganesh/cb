<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Mobilecmspages extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_drivermanagement;
	protected $resultJsonFactory; 
	protected $_mobilecms;
	protected $_storeManager;
	protected $request;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Cbhardware\Mobilecms\Model\MobilecmsFactory $_mobilecms,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement)
	{
		$this->_storeManager = $storeManager;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_drivermanagement = $_drivermanagement;
		$this->_mobilecms = $_mobilecms;
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$pageLimit = 50;
		$page = $this->request->getParam('page');
		$finalpage = ($page-1)*$pageLimit;
		$pagetype = $this->request->getParam('pagetype');

		$Mobilecms = $this->_mobilecms->create()->getCollection()
		->addFieldToFilter('type',array('eq'=>$pagetype))->addFieldToFilter('active',array('eq'=>'yes'));
		$Mobilecms->getSelect()->limit($pageLimit,$finalpage);
		$mobilecmspageData = $Mobilecms->getData();
		//print_r($mobilecmspageData);
		//exit();
		$data = array();
		if(!empty($pagetype)&&!empty($mobilecmspageData)&&$pagetype=='video'){
			foreach ($Mobilecms as $cmsData) {
				$data[]=array('categorytype'=>$cmsData->getType(),
					'pagetitle'=>$cmsData->getPageTitle(),
					'videotype'=>$cmsData->getVideotype(),
					'video_link'=>$cmsData->getVideoLink(),
					'content'=>$cmsData->getContent());
				$result = $this->resultJsonFactory->create();
				$result->setData(['videotabdetails'=>$data,'status'=>'success','page'=>'yes']);
			}
			//return $result;
		}else{
			if(!empty($pagetype)&&!empty($mobilecmspageData)&&$pagetype=='pdf'){
			foreach ($Mobilecms as $cmsData) {
				$data[]=array('categorytype'=>$cmsData->getType(),
					'pagetitle'=>$cmsData->getPageTitle(),
					'pdfpath'=>$this->_storeManager->getStore()->getBaseUrl().'pub/media/'.$cmsData->getPdfFilename(),
					'content'=>$cmsData->getContent());
				$result = $this->resultJsonFactory->create();
				$result->setData(['pdfdetails'=>$data,'status'=>'success','page'=>'yes']);
			}
			}else{
				$result = $this->resultJsonFactory->create();
				$result->setData(['status'=>'error','page'=>'no']);
			}
		}
		return $result;
		//print_r($mobilecmspageData);
		
	}
}
