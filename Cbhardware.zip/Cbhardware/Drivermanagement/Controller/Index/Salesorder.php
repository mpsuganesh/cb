<?php
namespace Cbhardware\Drivermanagement\Controller\Index;
use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Salesorder extends \Magento\Framework\App\Action\Action
{
	/*protected $_pageFactory;
	protected $_DrivermanagementFactory;


	public function __construct(\Magento\Framework\App\Action\Context $context,\Magento\Framework\View\Result\PageFactory $pageFactory,DrivermanagementFactory $TestimonialFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->_DrivermanagementFactory = $DrivermanagementFactory;
		return parent::__construct($context);
	}
*/
	public function execute()
	{
	 echo "test ssss";
	 exit();	
	}
}