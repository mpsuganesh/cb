<?php
namespace Cbhardware\Drivermanagement\Ui\Component\Listing\Column;

use Magento\Catalog\Helper\Image;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Ui\Component\Listing\Columns\Column;

class PurchaseordersImages extends \Magento\Ui\Component\Listing\Columns\Column
{
 const ALT_FIELD = 'title';

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param Image $imageHelper
     * @param UrlInterface $urlBuilder
     * @param StoreManagerInterface $storeManager
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        Image $imageHelper,
        UrlInterface $urlBuilder,
        StoreManagerInterface $storeManager,
        array $components = [],
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        $this->imageHelper = $imageHelper;
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        $mediaDirectory = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        if (isset($dataSource['data']['items'])) {  
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
                if(strrpos($item[$fieldName], '@')){
                    $multiimage = explode('@', $item[$fieldName]);
                    $badgeArray=array();
                    $imagesContainer='';
                    foreach ($multiimage as $multi){
                     $imagesArray = array(
                        [
                            'image_url'=>$multi,
                        ]
                    );

                     foreach ($imagesArray as $image) {
                        $imageUrl = $mediaDirectory.'purchaseordersignature/'.$image['image_url'];
                        $imagesContainer = $imagesContainer."<img src=". $imageUrl ." width='50px' height='50px' style='display:inline-block;margin:2px'/>";
                        $item[$fieldName . '_src'] = $imageUrl;
                        $item[$fieldName . '_alt'] = $this->getAlt($item) ?: '';
                        $item[$fieldName . '_orig_src'] = $imageUrl;
                    $item[$fieldName]=$imagesContainer;
                    }

                }

            }else{
               $imagesArray = array(
                [
                    'image_url'=>$item[$fieldName],
                ]
            );
               $badgeArray=array();
               $imagesContainer='';
               if($item[$fieldName] != ''){
                foreach ($imagesArray as $image) {
                    $imageUrl = $mediaDirectory.'purchaseordersignature/'.$image['image_url'];
                    $imagesContainer = $imagesContainer."<img src=". $imageUrl ." width='50px' height='50px' style='display:inline-block;margin:2px'/>";
                    $item[$fieldName . '_src'] = $imageUrl;
                    $item[$fieldName . '_alt'] = $this->getAlt($item) ?: '';
                    $item[$fieldName . '_orig_src'] = $imageUrl;
                $item[$fieldName]=$imagesContainer;
                }
            }else{
                $item[$fieldName]='';
            }
                    //$imagesName = $item[$fieldName];
        }
                //echo $item[$fieldName];
        
        
    }
}
       // exit();
return $dataSource;
}
}