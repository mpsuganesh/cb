<?php
namespace Cbhardware\Drivermanagement\Model;

use Cbhardware\Drivermanagement\Api\DriverdetailsInterface;

use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;

use Magento\Framework\App\ResourceConnectionFactory; 

class Driverdetails implements DriverdetailsInterface
{
    protected $_resourceConnection;

    protected $_drivermanagement;


    public function __construct(ResourceConnectionFactory $_resourceConnection,DrivermanagementFactory $_drivermanagement)
    {
        $this->_resourceConnection = $_resourceConnection;

        $this->_drivermanagement = $_drivermanagement;
    }
    
    public function driverdetails() {
		header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
        $driverData = $this->_drivermanagement->create()->getCollection()->addFieldToFilter('status',array('eq'=>'enable'));
        $diriverdetails = $driverData->getData();
$json = json_encode($diriverdetails,JSON_UNESCAPED_SLASHES);
        //foreach($driverData as $finaldata){
            /*$k2bDriverData = array();
            foreach ($driverData as $finaldata){
            $data = array("id"=>$finaldata->getId(),
            "drivername"=>$finaldata->getDriverName(),
            "email"=>$finaldata->getEmail(),
            "dob"=>$finaldata->getDob(),
            "licencenumber "=>$finaldata->getLicenceNumber(),
            "locations"=>$finaldata->getLocations()
            );

            $k2bDriverData[] = $data;

            }*/
            if(count($diriverdetails)>0){
       
            return $diriverdetails;
            }else{
                return "there is no data found..";
            }
            ////print_r($data);
            //exit();
       
    //}
       
    }
}
