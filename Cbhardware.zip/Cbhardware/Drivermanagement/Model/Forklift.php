<?php

namespace Cbhardware\Drivermanagement\Model;

use Magento\Cron\Exception;
use Magento\Framework\Model\AbstractModel;

/**
 * Drivermanagement Model
 *
 * @author      Pierre FAY
 */
class Forklift extends AbstractModel
{
    /**
     * @var \Magento\Framework\Stdlib\DateTime
     */
    protected $_dateTime;

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Cbhardware\Drivermanagement\Model\ResourceModel\Forklift::class);
    }
    
}