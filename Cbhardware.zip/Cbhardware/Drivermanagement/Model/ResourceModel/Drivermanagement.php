<?php
 
namespace Cbhardware\Drivermanagement\Model\ResourceModel;
 
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
 
class Drivermanagement extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('cbhardware_drivermanagement', 'id');
    }
}