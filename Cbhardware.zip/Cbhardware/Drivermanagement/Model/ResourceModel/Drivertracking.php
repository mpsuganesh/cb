<?php

namespace Cbhardware\Drivermanagement\Model\ResourceModel;
 
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Drivertracking extends AbstractDb
{
 
    public function _construct()
    {
        $this->_init('driver_tracking_details', 'id');
    }
}