<?php
		
namespace Cbhardware\Drivermanagement\Model\ResourceModel\Yardtask;
		
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
		
class Collection extends AbstractCollection			
{
	protected $_idFieldName = 'id';
			
    protected function _construct()
	{
			
        $this->_init(
			
            'Cbhardware\Drivermanagement\Model\Yardtask',
			
            'Cbhardware\Drivermanagement\Model\ResourceModel\Yardtask'
			
        );
			
    }
			
}