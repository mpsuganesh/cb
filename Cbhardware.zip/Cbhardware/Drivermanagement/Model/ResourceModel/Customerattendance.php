<?php

namespace Cbhardware\Drivermanagement\Model\ResourceModel;
 
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Contact Resource Model
 *
 * @author      Pierre FAY
 */
class Customerattendance extends AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('customer_attendance', 'id');
    }
}