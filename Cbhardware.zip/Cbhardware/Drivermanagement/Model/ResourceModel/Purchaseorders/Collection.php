<?php
		
namespace Cbhardware\Drivermanagement\Model\ResourceModel\Purchaseorders;
		
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
		
class Collection extends AbstractCollection			
{
	protected $_idFieldName = 'id';
			
    protected function _construct()
	{
			
        $this->_init(
			
            'Cbhardware\Drivermanagement\Model\Purchaseorders',
			
            'Cbhardware\Drivermanagement\Model\ResourceModel\Purchaseorders'
			
        );
			
    }
			
}