<?php
		
namespace Cbhardware\Drivermanagement\Model\ResourceModel\Individultracking;
		
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
		
class Collection extends AbstractCollection			
{
	protected $_idFieldName = 'id';
			
    protected function _construct()
	{
			
        $this->_init(
			
            'Cbhardware\Drivermanagement\Model\Individultracking',
			
            'Cbhardware\Drivermanagement\Model\ResourceModel\Individultracking'
			
        );
			
    }
			
}