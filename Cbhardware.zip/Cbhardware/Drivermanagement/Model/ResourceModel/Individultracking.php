<?php

namespace Cbhardware\Drivermanagement\Model\ResourceModel;
 
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Individultracking extends AbstractDb
{
 
    public function _construct()
    {
        $this->_init('cbhahardware_specific_driver_tracking', 'id');
    }
}