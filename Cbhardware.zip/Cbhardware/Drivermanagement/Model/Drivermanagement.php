<?php			

namespace Cbhardware\Drivermanagement\Model;
			
use Magento\Framework\Model\AbstractModel;
			
class Drivermanagement extends AbstractModel
{
			
    protected function _construct()
    {
			
        $this->_init('Cbhardware\Drivermanagement\Model\ResourceModel\Drivermanagement');
    }
			
}

	