<?php
namespace Cbhardware\Drivermanagement\Api;
 
interface DriverdetailsInterface
{
    /**
     * Returns greeting message to user
     *
     * @api
     * @param string $name Users name.
     * @return array mixed
     */
    public function driverdetails();
}
