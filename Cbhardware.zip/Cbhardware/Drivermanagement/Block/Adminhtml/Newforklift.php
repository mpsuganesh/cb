<?php
namespace Cbhardware\Drivermanagement\Block\Adminhtml;

use \Magento\Framework\View\Element\Template\Context;

class Newforklift extends \Magento\Framework\View\Element\Template
{
	public function __construct(Context $context,      
        \Magento\Store\Model\StoreManagerInterface $storeManager
    )
    {        
        $this->_storeManager = $storeManager;
        parent::__construct($context);
    }

    public function getBaseUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }

    public function getHeightData()
    {
        return $this->getHeight();
    }

    public function getWeightData()
    {
        return $this->getWeight();
    }

}