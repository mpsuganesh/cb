<?php
namespace Cbhardware\Drivermanagement\Block\Adminhtml;

class Drivermanagement extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml';
        $this->_blockGroup = 'Cbhardware_Drivermanagement';
        $this->_headerText = __('Manage Driver');
        $this->_addButtonLabel = __('Add New Driver');
        parent::_construct();
    }
}