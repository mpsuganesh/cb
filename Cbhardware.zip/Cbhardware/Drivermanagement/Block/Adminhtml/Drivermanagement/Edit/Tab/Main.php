<?php

namespace Cbhardware\Drivermanagement\Block\Adminhtml\Drivermanagement\Edit\Tab;

/**
 * Blog post edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;


    /**
     * @var \SR\Weblog\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        //\SR\Weblog\Model\Status $status,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        //$this->_status = $status;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /* @var $model \SR\Weblog\Model\BlogPosts */
        $model = $this->_coreRegistry->registry('cbhardware_drivermanagement');

        $isElementDisabled = false;

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Gendral Information')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }

        $fieldset->addField(
            'driver_name',
            'text',
            [
                'name' => 'drivername',
                'label' => __('Driver Name'),
                'title' => __('Driver Name'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Email'),
                'title' => __('Email'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'mobile_number',
            'text',
            [
                'name' => 'mobile_number',
                'label' => __('Mobile Number'),
                'title' => __('Mobile Number'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $dateFormat = $this->_localeDate->getDateFormat(
            \IntlDateFormatter::SHORT
        );
        $fieldset->addField(
            'dob',
            'date',
            [
                'name' => 'dob',
                'label' => __('Date of birth'),
                'date_format' => $dateFormat,
                'disabled' => $isElementDisabled,
                'class' => 'validate-date validate-date-range date-range-custom_theme-from',
                //'note' => 'Enter the some Date. after send notifications',
            ]
        );

        $fieldset->addField(
            'licence_number',
            'text',
            [
                'name' => 'licence_number',
                'label' => __('Licence Number'),
                'title' => __('Licence Number'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
       

        /* $fieldset->addField(
            'image',
            'image',
            array(
                'name' => 'push_img',
                'label' => __('Image'),
                'title' => __('Image'),
                'note' => 'Allow image type: jpg, jpeg, gif, png',
           )
        );*/
         
       /* $fieldset->addField(
            'content',
            'Cbhardware\Drivermanagement\Block\Adminhtml\Drivermanagement\Editor\Editor',
            [
                'name' => 'content',
                'label' => __('Contents'),
                'required' => true,
            ]
        );*/



         $fieldset->addField(
            'locations',
            'text',
            [
                'name' => 'locations',
                'label' => __('Locations'),
                'title' => __('Locations'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );

        $dateFormat = $this->_localeDate->getDateFormat(
            \IntlDateFormatter::SHORT
        );
        $fieldset->addField(
            'expire_date',
            'date',
            [
                'name' => 'date',
                'label' => __('Expire Date'),
                'date_format' => $dateFormat,
                'disabled' => $isElementDisabled,
                'class' => 'validate-date validate-date-range date-range-custom_theme-from',
                //'note' => 'Enter the some Date. after send notifications',
            ]
        );


        $fieldset->addField(
            'status',
            'select',
            array(
                'name' => 'status',
                'label' => __('Status'),
                'title' => __('Status'),
                'required' => true,
                'options' => ['enable' => __('enable'), 'disable' => __('disable')]
           )
        );

        /*$fieldset->addField(
            'is_active',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Status'),
                'name' => 'is_active',
                'required' => true,
                'options' => $this->_status->getOptionArray(),
                'disabled' => $isElementDisabled
            ]
        );*/
        /*if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }*/

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Gendral Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Gendral Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
