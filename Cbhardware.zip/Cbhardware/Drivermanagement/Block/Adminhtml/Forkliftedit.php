<?php
namespace Cbhardware\Drivermanagement\Block\Adminhtml;

use \Magento\Framework\View\Element\Template\Context;

class Forkliftedit extends \Magento\Framework\View\Element\Template
{
    protected $registry;
	public function __construct(Context $context,      
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Registry $registry
    )
    {        
        $this->_storeManager = $storeManager;
        $this->registry = $registry;
        parent::__construct($context);
    }

    public function getBaseUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }

    public function getHeightData()
    {
        return $this->getHeight();
    }

    public function getWeightData()
    {
        return $this->getWeight();
    }
    public function getCurrentdata(){
        return $this->registry->registry('cbhardware_drivermanagement');
    }

}