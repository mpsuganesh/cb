<?php

namespace Cbhardware\Mobileapi\Block\Adminhtml\Mobileapi\Edit\Tab;
/**
 * Blog post edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_resourceConnection;

    protected $_drivermanagement;
    protected $_viewHelper;

    /**
     * @var \SR\Weblog\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Cbhardware\Mobileapi\Helper\Data $viewHelper,
        //ResourceConnectionFactory $_resourceConnection,DrivermanagementFactory $_drivermanagement,
        //\SR\Weblog\Model\Status $status,
        array $data = []
    ) {
        $this->_viewHelper = $viewHelper;
        $this->_systemStore = $systemStore;
        //$this->_status = $status;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /* @var $model \SR\Weblog\Model\BlogPosts */
        $model = $this->_coreRegistry->registry('cbhardware_mobileapi');

        $isElementDisabled = false;

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Account Information')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }
        //echo "test...";
       // echo $this->_viewHelper->getAvailableCountries();
      // print_r($this->_viewHelper->getAvailableCountries()->getData());
       //exit();

        $fieldset->addField(
            'name',
            'text',
            [
                'name' => 'name',
                'label' => __('Account Name'),
                'title' => __('Account Name'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Account Email'),
                'title' => __('Account Email'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'street_address',
            'text',
            [
                'name' => 'street_address',
                'label' => __('Address line1'),
                'title' => __('Address line1'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'street_address_line_2',
            'text',
            [
                'name' => 'street_address_line_2',
                'label' => __('Address line2'),
                'title' => __('Address line2'),
                'required' => false,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'city',
            'text',
            [
                'name' => 'city',
                'label' => __('City'),
                'title' => __('City'),
                'required' => false,
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'state',
            'text',
            [
                'name' => 'state',
                'label' => __('State'),
                'title' => __('State'),
                'required' => false,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'country_id',
            'select',
            array(
                'name' => 'country_id',
                'label' => __('Select Your country'),
                'title' => __('Select Your country'),
                'required' => false,
                'options' => $this->_viewHelper->getAvailableCountries()
           )
        );
        $fieldset->addField(
            'postal_code',
            'text',
            [
                'name' => 'postal_code',
                'label' => __('Postal Code'),
                'title' => __('Postal Code'),
                'required' => false,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'mobile_no',
            'text',
            [
                'name' => 'mobile_no',
                'label' => __('Mobile Number'),
                'title' => __('Mobile Number'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'marital_status',
            'text',
            [
                'name' => 'marital_status',
                'label' => __('Marital Status'),
                'title' => __('Marital Status'),
                'required' => false,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'driver_details',
            'select',
            array(
                'name' => 'driver_details',
                'label' => __('Select Your driver'),
                'title' => __('Select Your driver'),
                'required' => true,
                'options' => $this->_viewHelper->getDriverdetails()
           )
        );
        $dateFormat = $this->_localeDate->getDateFormat(
            \IntlDateFormatter::SHORT
        );
         $fieldset->addField(
            'dob',
            'date',
            [
                'name' => 'dob',
                'label' => __('Date of birth'),
                'date_format' => $dateFormat,
                'disabled' => $isElementDisabled,
                'class' => 'validate-date validate-date-range date-range-custom_theme-from',
                //'note' => 'Enter the some Date. after send notifications',
            ]
        );
        $fieldset->addField(
            'profile_img',
            'image',
            array(
                'name' => 'profile_img',
                'label' => __('Profile Image'),
                'title' => __('Profile Image'),
                'note' => 'Allow image type: jpg, jpeg, gif, png',
           )
        );
        $fieldset->addField(
            'username',
            'text',
            [
                'name' => 'username',
                'label' => __('Username'),
                'title' => __('Username'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'password',
            'text',
            [
                'name' => 'password',
                'label' => __('Password'),
                'title' => __('Password'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'sales',
            'select',
            array(
                'name' => 'sales',
                'label' => __('Sales'),
                'title' => __('Sales'),
                'required' => true,
                'options' => ['yes' => __('yes'), 'no' => __('no')],
           )
        );
        $fieldset->addField(
            'picking',
            'select',
            array(
                'name' => 'picking',
                'label' => __('Picking'),
                'title' => __('Picking'),
                'required' => true,
                'options' => ['yes' => __('yes'), 'no' => __('no')]
           )
        );
        $fieldset->addField(
            'purchase',
            'select',
            array(
                'name' => 'purchase',
                'label' => __('Purchase'),
                'title' => __('Purchase'),
                'required' => true,
                'options' => ['yes' => __('yes'), 'no' => __('no')]
           )
        );
        $fieldset->addField(
            'vehicle',
            'select',
            array(
                'name' => 'vehicle',
                'label' => __('Vehicle'),
                'title' => __('Vehicle'),
                'required' => true,
                'options' => ['yes' => __('yes'), 'no' => __('no')]
           )
        );
        $fieldset->addField(
            'active',
            'select',
            array(
                'name' => 'active',
                'label' => __('Active'),
                'title' => __('Active'),
                'required' => true,
                'options' => ['yes' => __('yes'), 'no' => __('no')]
           )
        );

        


        /*$fieldset->addField(
            'is_active',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Status'),
                'name' => 'is_active',
                'required' => true,
                'options' => $this->_status->getOptionArray(),
                'disabled' => $isElementDisabled
            ]
        );*/
        /*if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }*/

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Gendral Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Gendral Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
