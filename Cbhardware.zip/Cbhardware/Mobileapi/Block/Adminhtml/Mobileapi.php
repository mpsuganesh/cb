<?php
namespace Cbhardware\Mobileapi\Block\Adminhtml;

class Mobileapi extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml';
        $this->_blockGroup = 'Cbhardware_Mobileapi';
        $this->_headerText = __('Manage Account');
        $this->_addButtonLabel = __('Add New Account');
        parent::_construct();
    }
}