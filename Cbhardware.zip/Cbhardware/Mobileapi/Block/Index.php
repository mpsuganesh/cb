<?php
namespace Cbhardware\Mobileapi\Block;
use Magento\Framework\ObjectManagerInterface;

class Index extends \Magento\Framework\View\Element\Template
{
	public function __construct(\Magento\Backend\Block\Template\Context $context,\Cbhardware\Mobileapi\Model\MobileapiFactory $modelFactory,
		ObjectManagerInterface $objectManager,
	array $data = [])
	{
	  $this->modelFactory = $modelFactory;
	  $this->objectManager = $objectManager;
	  parent::__construct($context, $data);
	}

	/*public function testimonial() {
	$model =  $this->modelFactory->create();
	$testCollection = $model->getCollection();
	
	return $testCollection->getData();
	}*/
	public function getMediaUrl(){
	 $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
	        ->getStore()
	        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

	    return $media_dir;

	}
}