<?php
namespace Cbhardware\Mobileapi\Helper;
/**
* 
*/
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $_resourceConnection;

    protected $_drivermanagement;

    protected $_countryCollectionFactory;
	
	public function __construct(\Magento\Framework\App\Helper\Context $context,
		\Magento\Framework\App\ResourceConnectionFactory $_resourceConnection,
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $_countryCollectionFactory,
        \Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement
    ){
    	parent::__construct($context);
    	$this->_resourceConnection = $_resourceConnection;
        $this->_countryCollectionFactory = $_countryCollectionFactory;
        $this->_drivermanagement = $_drivermanagement;

	}
	public function getDriverdetails(){
		$driverData = $this->_drivermanagement->create()->getCollection()->addFieldToFilter('status',array('eq'=>'enable'));
       // $diriverdetails = $driverData->getData();
        foreach($driverData as $driverDetail):
        	$result['0']="Select your driver";
            $result[$driverDetail->getId()] = $driverDetail->getDriverName();
        endforeach;
        return $result;
	}
    public function getAvailableCountries()
    {
        $collection = $this->_countryCollectionFactory->create();
        $collection->addFieldToSelect('*');
        foreach ($collection as $country) {
            $result['0']="Select your country";
            $result[$country->getName()] = $country->getName();
        }
        return $result;
    }
	
}
?>
