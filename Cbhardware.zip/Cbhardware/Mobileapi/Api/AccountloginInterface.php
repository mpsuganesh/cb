<?php
namespace Cbhardware\Mobileapi\Api;
 
interface AccountloginInterface
{
    /**
     * @api
     * @param string $username Users name.
     * @param string $password password.
     * @return \Magento\Framework\Json\Encoder
     */
    public function accountlogin($username,$password);
}
