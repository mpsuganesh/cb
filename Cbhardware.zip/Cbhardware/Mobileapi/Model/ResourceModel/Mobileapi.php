<?php
 
namespace Cbhardware\Mobileapi\Model\ResourceModel;
 
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
 
class Mobileapi extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('cbhardware_mobileapi', 'id');
    }
}