<?php			

namespace Cbhardware\Mobileapi\Model;
			
use Magento\Framework\Model\AbstractModel;
			
class Mobileapi extends AbstractModel
{
			
    protected function _construct()
    {
			
        $this->_init('Cbhardware\Mobileapi\Model\ResourceModel\Mobileapi');
    }
			
}

	