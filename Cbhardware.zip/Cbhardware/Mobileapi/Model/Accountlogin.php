<?php
namespace Cbhardware\Mobileapi\Model;

use Cbhardware\Mobileapi\Api\AccountloginInterface;
//use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;

//use Cbhardware\Mobileapi\Model\MobileapiFactory;

//use Magento\Framework\App\ResourceConnectionFactory; 

class Accountlogin implements AccountloginInterface
{
    protected $_resourceConnection;

    protected $_drivermanagement;
    /**
	 * @var \Magento\Framework\Json\Helper\Data
	 */
   protected $jsonHelper;
    
    protected $_mobileapi;
/**
 * Constructor.
 * 
 * @param \Magento\Framework\Json\Helper\Data $jsonHelper
 * @return array mixed
 */
    public function __construct(\Magento\Framework\App\ResourceConnectionFactory $_resourceConnection,
        \Cbhardware\Drivermanagement\Model\DrivermanagementFactory $_drivermanagement,
       \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Cbhardware\Mobileapi\Model\MobileapiFactory $_mobileapi
           
     )
    {
        $this->_resourceConnection = $_resourceConnection;
       $this->jsonHelper = $jsonHelper;
        $this->_drivermanagement = $_drivermanagement;
        $this->_mobileapi = $_mobileapi;
        
   
    }
  /**

 * @return array mixed
 */
    public function accountlogin($username,$password) {
        
         $driveraccountdetails = $this->_mobileapi->create()->getCollection()
         ->addFieldToFilter('username',array('eq'=>$username))
          ->addFieldToFilter('password',array('eq'=>$password));
         //echo $driveraccountdetails->getselect();
          
       // $driveraccountdetails = $driveraccountdetails->getData();
         foreach ($driveraccountdetails as $finaldata){
            

            if($finaldata->getDriverDetails() == 0){
				//$k2bDriverData['status'] ="success";
				  //$k2bDriverData['code'] ="200";
                $data = array("id"=>$finaldata->getId(),
                    "account"=>"Owner",
					"name"=>$finaldata->getName(),
					"email"=>$finaldata->getEmail(),
					"sales"=>$finaldata->getSales(),
					"picking"=>$finaldata->getPicking(),
					"purchase"=>$finaldata->getPurchase(),
					"vehicle"=>$finaldata->getVehicle(),
					"active"=>$finaldata->getActive(),
                 );
                 $k2bDriverData['accountdetails']= $data;

            }
            else{
                 $data = array("id"=>$finaldata->getId(),
                    "account"=>"Driver",
					"name"=>$finaldata->getName(),
					"email"=>$finaldata->getEmail(),
					"sales"=>$finaldata->getSales(),
					"picking"=>$finaldata->getPicking(),
					"purchase"=>$finaldata->getPurchase(),
					"vehicle"=>$finaldata->getVehicle(),
					"active"=>$finaldata->getActive(),
                 );

                 $k2bDriverData['accountdetails']= $data;
                 $driverData = $this->_drivermanagement->create()->getCollection()->addFieldToFilter('id',array('eq'=>$data['id']));
                 foreach ($driverData as $finaldata){
					$data = array("id"=>$finaldata->getId(),
					"drivername"=>$finaldata->getDriverName(),
					"email"=>$finaldata->getEmail(),
					"dob"=>$finaldata->getDob(),
					"licencenumber "=>$finaldata->getLicenceNumber(),
					"locations"=>$finaldata->getLocations()
					);
					$k2bDriverData['driverdetails']= $data;

				}
            
            }
           
           
            
            }
            
            if(count($k2bDriverData)>0){
            //$k2bDriverData = trim($result, '[]');
              
		  // $k2bdriver_datajson = json_encode($k2bDriverData);
               //$json = json_encode($data,JSON_UNESCAPED_SLASHES);
             //$encodedData = $this->jsonHelper->jsonEncode($result,JSON_UNESCAPED_SLASHES);
                //$k2bdriver_datajson = json_dcode($k2bDriverData);
 
    	return $k2bDriverData;
             
            
            
            }else{
                return "there is no data found..";
            }
           
       
    //}
       
    }
}
