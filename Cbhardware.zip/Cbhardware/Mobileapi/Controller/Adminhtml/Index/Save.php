<?php
namespace Cbhardware\Mobileapi\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;

class Save extends \Magento\Backend\App\Action
{

    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context)
    {
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $store = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface');
        
        $currentStore = $store->getStore();
        
        $mediaurl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);


        if ($data) {
            $model = $this->_objectManager->create('Cbhardware\Mobileapi\Model\Mobileapi');

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }

            try {
               // print_r($data);
                //exit();

                $k2b_path = 'pub/media/myprofile/';

                $name = $_FILES['profile_img']['name'];
                $fname = "/myprofile/".$name;

                $tmp_name = $_FILES['profile_img']['tmp_name'];

                move_uploaded_file($tmp_name, $k2b_path.$name);

                $path_name =$name;
                $model->setName($data['name']);
                $model->setEmail($data['email']);
                $model->setStreetAddress($data['street_address']);
                $model->setStreetAddressLine2($data['street_address_line_2']);
                $model->setCity($data['city']);
                $model->setCountryId($data['country_id']);
                $model->setState($data['state']);
                $model->setPostalCode($data['postal_code']);
                $model->setMobileNo($data['mobile_no']);
                $model->setMaritalStatus($data['marital_status']);
                $model->setDob($data['dob']);
                $model->setDriverDetails($data['driver_details']);
                $model->setUsername($data['username']);
                $model->setPassword($data['password']);
                $model->setSales($data['sales']);
                $model->setPicking($data['picking']);
                $model->setPurchase($data['purchase']);
                $model->setVehicle($data['vehicle']);
                $model->setActive($data['active']);
                if(!empty($name)){
                $model->setprofile_img($fname);
                }
                //$model->setData($data);
                
                $model->save();
                $this->messageManager->addSuccess(__('The Account has been saved.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving this driver.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
