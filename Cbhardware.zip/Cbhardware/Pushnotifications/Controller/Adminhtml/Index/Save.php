<?php
namespace Cbhardware\Pushnotifications\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;

class Save extends \Magento\Backend\App\Action
{
    protected $_mediaDirectory;
    protected $_fileUploaderFactory;

    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context,
       \Magento\Framework\Filesystem $filesystem,
       \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory)
    {
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    { 
        $image = $this->getRequest()->getFiles();
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $store = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface');
        
        $currentStore = $store->getStore();
        
        $mediaurl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);


        if ($data) {
            $model = $this->_objectManager->create('Cbhardware\Pushnotifications\Model\Pushnotifications');

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
            
            try {
              $model1 = $this->_objectManager->create('Cbhardware\Pushnotifications\Model\Pushnotifications')->getCollection();
              if(empty($model1->getData())||!empty($id)){
                $path = $this->_mediaDirectory->getAbsolutePath('mobileiosdata/');;
              if(isset($data['file_name']['delete'])){
                unlink($this->_mediaDirectory->getAbsolutePath('/').$data['file_name']['value']);
                $data['file_name'] = '';
            }else if($image['file_name']['name'] != ''){
            // Save Image
                $uploader = $this->_fileUploaderFactory->create(['fileId' => $image['file_name']]);
                $uploader->setAllowedExtensions(['pem']);
                $uploader->setAllowRenameFiles(true);
                $result = $uploader->save($path);

                $fileName = $uploader->getUploadedFileName();
                if ($fileName) {
                    $data['file_name'] = 'mobileiosdata/'.$fileName;
                }
            // Save Image
            }else{
                $data['file_name'] = NULL;
            }
            $model->setData($data);
            $model->save();
            $this->messageManager->addSuccess(__('The data has been saved.'));
            $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
            if ($this->getRequest()->getParam('back')) {
                return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
            }

              }else{
                 $this->messageManager->addError('allowed only one data');
              }
              
            
            return $resultRedirect->setPath('*/*/');
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\Exception $e) {
           $this->messageManager->addError($e->getMessage());
       }

       $this->_getSession()->setFormData($data);
       return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
   }
   return $resultRedirect->setPath('*/*/');
}
}
