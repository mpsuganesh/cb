<?php
namespace Cbhardware\Mobileapi\Controller\Index;
//use Cbhardware\Mobileapi\Model\MobileapiFactory;
class OrderDetails extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $_MobileapiFactory;
    protected $_orderCollectionFactory;
    protected $orders;

	public function __construct(\Magento\Framework\App\Action\Context $context,
	\Magento\Framework\View\Result\PageFactory $pageFactory,
	 \Cbhardware\Mobileapi\Model\MobileapiFactory $MobileapiFactory,
	  \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->_MobileapiFactory = $MobileapiFactory;
		 $this->_orderCollectionFactory = $orderCollectionFactory;  
		return parent::__construct($context);
	}

	public function execute()
	{
		 $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
			$orderDatamodel = $objectManager->get('Magento\Sales\Model\Order')->getCollection();
			foreach($orderDatamodel as $orderDatamodel1){
			//echo '<pre>';
			//print_r($orderDatamodel1->getData());
			//echo '</pre>';

			}
			$login = 'CampbelltownBui2AU';
			$password = '7a470987cd7543ba986ec7cc09271f1b';
			$url = 'https://api.cin7.com/api/v1/SalesOrders/?source=Magento 2&where=source%3D"Magento 2"';
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			curl_setopt($ch, CURLOPT_USERPWD, "$login:$password");
			$result = curl_exec($ch);
			curl_close($ch);  
			print_r($result);
		//echo "test rr";
		//$newsModel = $this->_TestimonialFactory->create();
		//$newsCollection = $newsModel->getCollection();
        // Load all data of collection
        //var_dump($newsCollection->getData());
		//exit();
		//return $this->_pageFactory->create();
	}
}
