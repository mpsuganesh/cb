<?php			

namespace Cbhardware\Pushnotifications\Model;
			
use Magento\Framework\Model\AbstractModel;
			
class Pushnotifications extends AbstractModel
{
			
    protected function _construct()
    {
			
        $this->_init('Cbhardware\Pushnotifications\Model\ResourceModel\Pushnotifications');
    }
			
}

	