<?php

namespace Cbhardware\Pushnotifications\Block\Adminhtml\Pushnotifications\Edit\Tab;
/**
 * Blog post edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_resourceConnection;

    protected $_drivermanagement;
    protected $_viewHelper;

    /**
     * @var \SR\Weblog\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Cbhardware\Mobilecms\Helper\Data $viewHelper,
        //ResourceConnectionFactory $_resourceConnection,DrivermanagementFactory $_drivermanagement,
        //\SR\Weblog\Model\Status $status,
        array $data = []
    ) {
        $this->_viewHelper = $viewHelper;
        $this->_systemStore = $systemStore;
        //$this->_status = $status;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /* @var $model \SR\Weblog\Model\BlogPosts */
        $model = $this->_coreRegistry->registry('cbhardware_pushnotifications');
       // print_r($model->getData());

        $isElementDisabled = false;

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Information')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }
        $fieldset->addField(
            'secret_key',
            'text',
            [
                'name' => 'secret_key',
                'label' => __('Secreate Key'),
                'title' => __('Secreate Key'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
       /* $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Account Email'),
                'title' => __('Account Email'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );*/
        $fieldset->addField(
            'file_name',
            'image',
            array(
                'name' => 'file_name',
                'label' => __('Permission File'),
                'title' => __('Pdf Upload'),
                'note' => 'Allow file type: pem',
           )
        );

        $fieldset->addField(
            'gateway_url_test',
            'text',
            [
                'name' => 'gateway_url_test',
                'label' => __('Gateway Url Test'),
                'title' => __('Gateway Url Test'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'gateway_url_live',
            'text',
            [
                'name' => 'gateway_url_live',
                'label' => __('Gateway Url Live'),
                'title' => __('Gateway Url Live'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'status',
            'select',
            array(
                'name' => 'status',
                'label' => __('Mode'),
                'title' => __('Mode'),
                'required' => false,
                'options' => ['0' => __('Select Your mode'),'test' => __('Test'), 'live' => __('Live')]
           )
        );
        $fieldset->addField(
            'msg_title',
            'text',
            [
                'name' => 'msg_title',
                'label' => __('Message Title'),
                'title' => __('Message Title'),
                'required' => false,
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'msg_desc',
            'Cbhardware\Pushnotifications\Block\Adminhtml\Pushnotifications\Editor\Editor',
            [
                'name' => 'msg_desc',
                'label' => __('Contents'),
                'required' => false,
            ]
        );

        $fieldset->addField(
            'active',
            'select',
            array(
                'name' => 'active',
                'label' => __('Active'),
                'title' => __('Active'),
                'required' => false,
                'options' => ['yes' => __('yes'), 'no' => __('no')]
           )
        );

        /*$fieldset->addField(
            'is_active',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Status'),
                'name' => 'is_active',
                'required' => true,
                'options' => $this->_status->getOptionArray(),
                'disabled' => $isElementDisabled
            ]
        );*/
        /*if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }*/

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Gendral Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Gendral Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
