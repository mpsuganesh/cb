<?php
namespace Custom\ApplyGiftvoucher\Controller\Index;
//use Cbhardware\Drivermanagement\Model\DrivermanagementFactory;
class Validatevoucher extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $resultJsonFactory; 
	protected $_giftvoucher;
	protected $request;
	protected $_mediaDirectory;

	public function __construct(\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Custom\ApplyGiftvoucher\Model\ApplyGiftvoucherFactory $_giftvoucher,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Framework\Filesystem $filesystem)
	{
		$this->resultJsonFactory = $resultJsonFactory;
		$this->_pageFactory = $pageFactory;
		$this->_giftvoucher = $_giftvoucher;
		$this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
		$this->request = $request;
		return parent::__construct($context);
		
	}

	public function execute()
	{
		$voucherCode = $this->getRequest()->getPost('applycode');
		$pinNumber = $this->getRequest()->getPost('pin');

		$giftDetails = $this->_giftvoucher->create()->getCollection()->addFieldToFilter('giftcode',array('eq'=>$voucherCode))->addFieldToFilter('pin',array('eq'=>$pinNumber))->addFieldToFilter('enable',array('eq'=>'E'));
		if(!empty($giftDetails->getData())){
			foreach ($giftDetails as $giftData) {
				$giftAmount = $giftData->getAmount();
				$giftcode = $giftData->getgiftcode();
				$datas["giftcode"] =$giftcode;
				$datas["giftamount"] = $giftAmount;
				$datas["status"] = "success";
				$datas["message"] = "success fully applied";
				# code...
			}

		//print_r($giftDetails->getData());
		}else{
			$datas["status"] = "error";
			$datas["message"] = "This voucher is not valid";
		}
		echo json_encode($datas);
		//echo $voucherCode;
		//echo "test";
		//exit();
	}
}