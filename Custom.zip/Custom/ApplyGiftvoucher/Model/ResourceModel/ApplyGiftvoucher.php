<?php
 
namespace Custom\ApplyGiftvoucher\Model\ResourceModel;
 
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
 
class ApplyGiftvoucher extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('gift_voucher', 'id');
    }
}