<?php			

namespace Custom\ApplyGiftvoucher\Model;
			
use Magento\Framework\Model\AbstractModel;
			
class ApplyGiftvoucher extends AbstractModel
{
			
    protected function _construct()
    {
			
        $this->_init('Custom\ApplyGiftvoucher\Model\ResourceModel\ApplyGiftvoucher');
    }
			
}

	